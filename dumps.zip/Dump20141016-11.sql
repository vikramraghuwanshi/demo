CREATE DATABASE  IF NOT EXISTS `magento_a` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `magento_a`;
-- MySQL dump 10.13  Distrib 5.6.19, for linux-glibc2.5 (x86_64)
--
-- Host: 85.25.84.108    Database: magento_a
-- ------------------------------------------------------
-- Server version	5.5.38-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oauth_consumer`
--

DROP TABLE IF EXISTS `oauth_consumer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_consumer` (
  `entity_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Entity Id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Created At',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Updated At',
  `name` varchar(255) NOT NULL COMMENT 'Name of consumer',
  `key` varchar(32) NOT NULL COMMENT 'Key code',
  `secret` varchar(32) NOT NULL COMMENT 'Secret code',
  `callback_url` varchar(255) DEFAULT NULL COMMENT 'Callback URL',
  `rejected_callback_url` varchar(255) NOT NULL COMMENT 'Rejected callback URL',
  PRIMARY KEY (`entity_id`),
  UNIQUE KEY `UNQ_OAUTH_CONSUMER_KEY` (`key`),
  UNIQUE KEY `UNQ_OAUTH_CONSUMER_SECRET` (`secret`),
  KEY `IDX_OAUTH_CONSUMER_CREATED_AT` (`created_at`),
  KEY `IDX_OAUTH_CONSUMER_UPDATED_AT` (`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='OAuth Consumers';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_consumer`
--

LOCK TABLES `oauth_consumer` WRITE;
/*!40000 ALTER TABLE `oauth_consumer` DISABLE KEYS */;
INSERT INTO `oauth_consumer` VALUES (1,'2014-10-08 08:50:36','2014-10-08 06:50:36','admin','77c1d83e358132c835422f1eeb0141e1','f3f29c6862e57d61681aed717f269d2b',NULL,''),(2,'2014-10-14 05:00:18','2014-10-14 03:00:18','guido','01e37313a433aea3f1a88b3d69e5af25','8edc55edf98c8b15dce99e34a5e67773',NULL,'');
/*!40000 ALTER TABLE `oauth_consumer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_nonce`
--

DROP TABLE IF EXISTS `oauth_nonce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_nonce` (
  `nonce` varchar(32) NOT NULL COMMENT 'Nonce String',
  `timestamp` int(10) unsigned NOT NULL COMMENT 'Nonce Timestamp',
  UNIQUE KEY `UNQ_OAUTH_NONCE_NONCE` (`nonce`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='oauth_nonce';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_nonce`
--

LOCK TABLES `oauth_nonce` WRITE;
/*!40000 ALTER TABLE `oauth_nonce` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_nonce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_token`
--

DROP TABLE IF EXISTS `oauth_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_token` (
  `entity_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Entity ID',
  `consumer_id` int(10) unsigned NOT NULL COMMENT 'Consumer ID',
  `admin_id` int(10) unsigned DEFAULT NULL COMMENT 'Admin user ID',
  `customer_id` int(10) unsigned DEFAULT NULL COMMENT 'Customer user ID',
  `type` varchar(16) NOT NULL COMMENT 'Token Type',
  `token` varchar(32) NOT NULL COMMENT 'Token',
  `secret` varchar(32) NOT NULL COMMENT 'Token Secret',
  `verifier` varchar(32) DEFAULT NULL COMMENT 'Token Verifier',
  `callback_url` varchar(255) NOT NULL COMMENT 'Token Callback URL',
  `revoked` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Is Token revoked',
  `authorized` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Is Token authorized',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Token creation timestamp',
  PRIMARY KEY (`entity_id`),
  UNIQUE KEY `UNQ_OAUTH_TOKEN_TOKEN` (`token`),
  KEY `IDX_OAUTH_TOKEN_CONSUMER_ID` (`consumer_id`),
  KEY `FK_OAUTH_TOKEN_ADMIN_ID_ADMIN_USER_USER_ID` (`admin_id`),
  KEY `FK_OAUTH_TOKEN_CUSTOMER_ID_CUSTOMER_ENTITY_ENTITY_ID` (`customer_id`),
  CONSTRAINT `FK_OAUTH_TOKEN_ADMIN_ID_ADMIN_USER_USER_ID` FOREIGN KEY (`admin_id`) REFERENCES `admin_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_OAUTH_TOKEN_CONSUMER_ID_OAUTH_CONSUMER_ENTITY_ID` FOREIGN KEY (`consumer_id`) REFERENCES `oauth_consumer` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_OAUTH_TOKEN_CUSTOMER_ID_CUSTOMER_ENTITY_ENTITY_ID` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='OAuth Tokens';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_token`
--

LOCK TABLES `oauth_token` WRITE;
/*!40000 ALTER TABLE `oauth_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_cert`
--

DROP TABLE IF EXISTS `paypal_cert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_cert` (
  `cert_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Cert Id',
  `website_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Website Id',
  `content` text COMMENT 'Content',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Updated At',
  PRIMARY KEY (`cert_id`),
  KEY `IDX_PAYPAL_CERT_WEBSITE_ID` (`website_id`),
  CONSTRAINT `FK_PAYPAL_CERT_WEBSITE_ID_CORE_WEBSITE_WEBSITE_ID` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Paypal Certificate Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_cert`
--

LOCK TABLES `paypal_cert` WRITE;
/*!40000 ALTER TABLE `paypal_cert` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_cert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_payment_transaction`
--

DROP TABLE IF EXISTS `paypal_payment_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_payment_transaction` (
  `transaction_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Entity Id',
  `txn_id` varchar(100) DEFAULT NULL COMMENT 'Txn Id',
  `additional_information` blob COMMENT 'Additional Information',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Created At',
  PRIMARY KEY (`transaction_id`),
  UNIQUE KEY `UNQ_PAYPAL_PAYMENT_TRANSACTION_TXN_ID` (`txn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='PayPal Payflow Link Payment Transaction';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_payment_transaction`
--

LOCK TABLES `paypal_payment_transaction` WRITE;
/*!40000 ALTER TABLE `paypal_payment_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_payment_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_settlement_report`
--

DROP TABLE IF EXISTS `paypal_settlement_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_settlement_report` (
  `report_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Report Id',
  `report_date` timestamp NULL DEFAULT NULL COMMENT 'Report Date',
  `account_id` varchar(64) DEFAULT NULL COMMENT 'Account Id',
  `filename` varchar(24) DEFAULT NULL COMMENT 'Filename',
  `last_modified` timestamp NULL DEFAULT NULL COMMENT 'Last Modified',
  PRIMARY KEY (`report_id`),
  UNIQUE KEY `UNQ_PAYPAL_SETTLEMENT_REPORT_REPORT_DATE_ACCOUNT_ID` (`report_date`,`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Paypal Settlement Report Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_settlement_report`
--

LOCK TABLES `paypal_settlement_report` WRITE;
/*!40000 ALTER TABLE `paypal_settlement_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_settlement_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_settlement_report_row`
--

DROP TABLE IF EXISTS `paypal_settlement_report_row`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_settlement_report_row` (
  `row_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Row Id',
  `report_id` int(10) unsigned NOT NULL COMMENT 'Report Id',
  `transaction_id` varchar(19) DEFAULT NULL COMMENT 'Transaction Id',
  `invoice_id` varchar(127) DEFAULT NULL COMMENT 'Invoice Id',
  `paypal_reference_id` varchar(19) DEFAULT NULL COMMENT 'Paypal Reference Id',
  `paypal_reference_id_type` varchar(3) DEFAULT NULL COMMENT 'Paypal Reference Id Type',
  `transaction_event_code` varchar(5) DEFAULT NULL COMMENT 'Transaction Event Code',
  `transaction_initiation_date` timestamp NULL DEFAULT NULL COMMENT 'Transaction Initiation Date',
  `transaction_completion_date` timestamp NULL DEFAULT NULL COMMENT 'Transaction Completion Date',
  `transaction_debit_or_credit` varchar(2) NOT NULL DEFAULT 'CR' COMMENT 'Transaction Debit Or Credit',
  `gross_transaction_amount` decimal(20,6) NOT NULL DEFAULT '0.000000' COMMENT 'Gross Transaction Amount',
  `gross_transaction_currency` varchar(3) DEFAULT '' COMMENT 'Gross Transaction Currency',
  `fee_debit_or_credit` varchar(2) DEFAULT NULL COMMENT 'Fee Debit Or Credit',
  `fee_amount` decimal(20,6) NOT NULL DEFAULT '0.000000' COMMENT 'Fee Amount',
  `fee_currency` varchar(3) DEFAULT NULL COMMENT 'Fee Currency',
  `custom_field` varchar(255) DEFAULT NULL COMMENT 'Custom Field',
  `consumer_id` varchar(127) DEFAULT NULL COMMENT 'Consumer Id',
  `payment_tracking_id` varchar(255) DEFAULT NULL COMMENT 'Payment Tracking ID',
  `store_id` varchar(50) DEFAULT NULL COMMENT 'Store ID',
  PRIMARY KEY (`row_id`),
  KEY `IDX_PAYPAL_SETTLEMENT_REPORT_ROW_REPORT_ID` (`report_id`),
  CONSTRAINT `FK_B0234CCA0A59BECD0BF179CC6B28399C` FOREIGN KEY (`report_id`) REFERENCES `paypal_settlement_report` (`report_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Paypal Settlement Report Row Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_settlement_report_row`
--

LOCK TABLES `paypal_settlement_report_row` WRITE;
/*!40000 ALTER TABLE `paypal_settlement_report_row` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_settlement_report_row` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypalauth_customer`
--

DROP TABLE IF EXISTS `paypalauth_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypalauth_customer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `payer_id` varchar(255) NOT NULL DEFAULT '',
  `customer_id` int(10) unsigned NOT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_UNIQUE_PAYER_ID` (`payer_id`),
  UNIQUE KEY `IDX_UNIQUE_CUSTOMER_ID` (`customer_id`),
  KEY `FK_CUSTOMER_PAYPAL_CUSTOMER_ID` (`customer_id`),
  CONSTRAINT `FK_CUSTOMER_PAYPAL_CUSTOMER_ID` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypalauth_customer`
--

LOCK TABLES `paypalauth_customer` WRITE;
/*!40000 ALTER TABLE `paypalauth_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypalauth_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `persistent_session`
--

DROP TABLE IF EXISTS `persistent_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `persistent_session` (
  `persistent_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Session id',
  `key` varchar(50) NOT NULL COMMENT 'Unique cookie key',
  `customer_id` int(10) unsigned DEFAULT NULL COMMENT 'Customer id',
  `website_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Website ID',
  `info` text COMMENT 'Session Data',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Updated At',
  PRIMARY KEY (`persistent_id`),
  UNIQUE KEY `IDX_PERSISTENT_SESSION_KEY` (`key`),
  UNIQUE KEY `IDX_PERSISTENT_SESSION_CUSTOMER_ID` (`customer_id`),
  KEY `IDX_PERSISTENT_SESSION_UPDATED_AT` (`updated_at`),
  KEY `FK_PERSISTENT_SESSION_WEBSITE_ID_CORE_WEBSITE_WEBSITE_ID` (`website_id`),
  CONSTRAINT `FK_PERSISTENT_SESSION_WEBSITE_ID_CORE_WEBSITE_WEBSITE_ID` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_PERSISTENT_SESS_CSTR_ID_CSTR_ENTT_ENTT_ID` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Persistent Session';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persistent_session`
--

LOCK TABLES `persistent_session` WRITE;
/*!40000 ALTER TABLE `persistent_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `persistent_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll`
--

DROP TABLE IF EXISTS `poll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll` (
  `poll_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Poll Id',
  `poll_title` varchar(255) DEFAULT NULL COMMENT 'Poll title',
  `votes_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Votes Count',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store id',
  `date_posted` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date posted',
  `date_closed` timestamp NULL DEFAULT NULL COMMENT 'Date closed',
  `active` smallint(6) NOT NULL DEFAULT '1' COMMENT 'Is active',
  `closed` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Is closed',
  `answers_display` smallint(6) DEFAULT NULL COMMENT 'Answers display',
  PRIMARY KEY (`poll_id`),
  KEY `IDX_POLL_STORE_ID` (`store_id`),
  CONSTRAINT `FK_POLL_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Poll';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll`
--

LOCK TABLES `poll` WRITE;
/*!40000 ALTER TABLE `poll` DISABLE KEYS */;
INSERT INTO `poll` VALUES (1,'What is your favorite color',7,0,'2014-05-15 23:02:23',NULL,1,0,NULL);
/*!40000 ALTER TABLE `poll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_answer`
--

DROP TABLE IF EXISTS `poll_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_answer` (
  `answer_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Answer Id',
  `poll_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Poll Id',
  `answer_title` varchar(255) DEFAULT NULL COMMENT 'Answer title',
  `votes_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Votes Count',
  `answer_order` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Answers display',
  PRIMARY KEY (`answer_id`),
  KEY `IDX_POLL_ANSWER_POLL_ID` (`poll_id`),
  CONSTRAINT `FK_POLL_ANSWER_POLL_ID_POLL_POLL_ID` FOREIGN KEY (`poll_id`) REFERENCES `poll` (`poll_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='Poll Answers';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_answer`
--

LOCK TABLES `poll_answer` WRITE;
/*!40000 ALTER TABLE `poll_answer` DISABLE KEYS */;
INSERT INTO `poll_answer` VALUES (1,1,'Green',4,0),(2,1,'Red',1,0),(3,1,'Black',0,0),(4,1,'Magenta',2,0);
/*!40000 ALTER TABLE `poll_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_store`
--

DROP TABLE IF EXISTS `poll_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_store` (
  `poll_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Poll Id',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store id',
  PRIMARY KEY (`poll_id`,`store_id`),
  KEY `IDX_POLL_STORE_STORE_ID` (`store_id`),
  CONSTRAINT `FK_POLL_STORE_POLL_ID_POLL_POLL_ID` FOREIGN KEY (`poll_id`) REFERENCES `poll` (`poll_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_POLL_STORE_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Poll Store';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_store`
--

LOCK TABLES `poll_store` WRITE;
/*!40000 ALTER TABLE `poll_store` DISABLE KEYS */;
INSERT INTO `poll_store` VALUES (1,1);
/*!40000 ALTER TABLE `poll_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_vote`
--

DROP TABLE IF EXISTS `poll_vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_vote` (
  `vote_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Vote Id',
  `poll_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Poll Id',
  `poll_answer_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Poll answer id',
  `ip_address` bigint(20) DEFAULT NULL COMMENT 'Poll answer id',
  `customer_id` int(11) DEFAULT NULL COMMENT 'Customer id',
  `vote_time` timestamp NULL DEFAULT NULL COMMENT 'Date closed',
  PRIMARY KEY (`vote_id`),
  KEY `IDX_POLL_VOTE_POLL_ANSWER_ID` (`poll_answer_id`),
  CONSTRAINT `FK_POLL_VOTE_POLL_ANSWER_ID_POLL_ANSWER_ANSWER_ID` FOREIGN KEY (`poll_answer_id`) REFERENCES `poll_answer` (`answer_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Poll Vote';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_vote`
--

LOCK TABLES `poll_vote` WRITE;
/*!40000 ALTER TABLE `poll_vote` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_alert_price`
--

DROP TABLE IF EXISTS `product_alert_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_alert_price` (
  `alert_price_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Product alert price id',
  `customer_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Customer id',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Product id',
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000' COMMENT 'Price amount',
  `website_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Website id',
  `add_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Product alert add date',
  `last_send_date` timestamp NULL DEFAULT NULL COMMENT 'Product alert last send date',
  `send_count` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Product alert send count',
  `status` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Product alert status',
  PRIMARY KEY (`alert_price_id`),
  KEY `IDX_PRODUCT_ALERT_PRICE_CUSTOMER_ID` (`customer_id`),
  KEY `IDX_PRODUCT_ALERT_PRICE_PRODUCT_ID` (`product_id`),
  KEY `IDX_PRODUCT_ALERT_PRICE_WEBSITE_ID` (`website_id`),
  CONSTRAINT `FK_PRD_ALERT_PRICE_CSTR_ID_CSTR_ENTT_ENTT_ID` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRD_ALERT_PRICE_PRD_ID_CAT_PRD_ENTT_ENTT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRODUCT_ALERT_PRICE_WEBSITE_ID_CORE_WEBSITE_WEBSITE_ID` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Product Alert Price';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_alert_price`
--

LOCK TABLES `product_alert_price` WRITE;
/*!40000 ALTER TABLE `product_alert_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_alert_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_alert_stock`
--

DROP TABLE IF EXISTS `product_alert_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_alert_stock` (
  `alert_stock_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Product alert stock id',
  `customer_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Customer id',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Product id',
  `website_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Website id',
  `add_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Product alert add date',
  `send_date` timestamp NULL DEFAULT NULL COMMENT 'Product alert send date',
  `send_count` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Send Count',
  `status` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Product alert status',
  PRIMARY KEY (`alert_stock_id`),
  KEY `IDX_PRODUCT_ALERT_STOCK_CUSTOMER_ID` (`customer_id`),
  KEY `IDX_PRODUCT_ALERT_STOCK_PRODUCT_ID` (`product_id`),
  KEY `IDX_PRODUCT_ALERT_STOCK_WEBSITE_ID` (`website_id`),
  CONSTRAINT `FK_PRD_ALERT_STOCK_CSTR_ID_CSTR_ENTT_ENTT_ID` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRD_ALERT_STOCK_PRD_ID_CAT_PRD_ENTT_ENTT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PRODUCT_ALERT_STOCK_WEBSITE_ID_CORE_WEBSITE_WEBSITE_ID` FOREIGN KEY (`website_id`) REFERENCES `core_website` (`website_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Product Alert Stock';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_alert_stock`
--

LOCK TABLES `product_alert_stock` WRITE;
/*!40000 ALTER TABLE `product_alert_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_alert_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating` (
  `rating_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Rating Id',
  `entity_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity Id',
  `rating_code` varchar(64) NOT NULL COMMENT 'Rating Code',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating Position On Frontend',
  PRIMARY KEY (`rating_id`),
  UNIQUE KEY `UNQ_RATING_RATING_CODE` (`rating_code`),
  KEY `IDX_RATING_ENTITY_ID` (`entity_id`),
  CONSTRAINT `FK_RATING_ENTITY_ID_RATING_ENTITY_ENTITY_ID` FOREIGN KEY (`entity_id`) REFERENCES `rating_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Ratings';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating`
--

LOCK TABLES `rating` WRITE;
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;
INSERT INTO `rating` VALUES (1,1,'Quality',0),(2,1,'Value',0),(3,1,'Price',0);
/*!40000 ALTER TABLE `rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating_entity`
--

DROP TABLE IF EXISTS `rating_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating_entity` (
  `entity_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Entity Id',
  `entity_code` varchar(64) NOT NULL COMMENT 'Entity Code',
  PRIMARY KEY (`entity_id`),
  UNIQUE KEY `UNQ_RATING_ENTITY_ENTITY_CODE` (`entity_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Rating entities';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating_entity`
--

LOCK TABLES `rating_entity` WRITE;
/*!40000 ALTER TABLE `rating_entity` DISABLE KEYS */;
INSERT INTO `rating_entity` VALUES (1,'product'),(2,'product_review'),(3,'review');
/*!40000 ALTER TABLE `rating_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating_option`
--

DROP TABLE IF EXISTS `rating_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating_option` (
  `option_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Rating Option Id',
  `rating_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating Id',
  `code` varchar(32) NOT NULL COMMENT 'Rating Option Code',
  `value` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating Option Value',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Ration option position on frontend',
  PRIMARY KEY (`option_id`),
  KEY `IDX_RATING_OPTION_RATING_ID` (`rating_id`),
  CONSTRAINT `FK_RATING_OPTION_RATING_ID_RATING_RATING_ID` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='Rating options';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating_option`
--

LOCK TABLES `rating_option` WRITE;
/*!40000 ALTER TABLE `rating_option` DISABLE KEYS */;
INSERT INTO `rating_option` VALUES (1,1,'1',1,1),(2,1,'2',2,2),(3,1,'3',3,3),(4,1,'4',4,4),(5,1,'5',5,5),(6,2,'1',1,1),(7,2,'2',2,2),(8,2,'3',3,3),(9,2,'4',4,4),(10,2,'5',5,5),(11,3,'1',1,1),(12,3,'2',2,2),(13,3,'3',3,3),(14,3,'4',4,4),(15,3,'5',5,5);
/*!40000 ALTER TABLE `rating_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating_option_vote`
--

DROP TABLE IF EXISTS `rating_option_vote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating_option_vote` (
  `vote_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Vote id',
  `option_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Vote option id',
  `remote_ip` varchar(16) NOT NULL COMMENT 'Customer IP',
  `remote_ip_long` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Customer IP converted to long integer format',
  `customer_id` int(10) unsigned DEFAULT '0' COMMENT 'Customer Id',
  `entity_pk_value` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Product id',
  `rating_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating id',
  `review_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Review id',
  `percent` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Percent amount',
  `value` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Vote option value',
  PRIMARY KEY (`vote_id`),
  KEY `IDX_RATING_OPTION_VOTE_OPTION_ID` (`option_id`),
  KEY `FK_RATING_OPTION_VOTE_REVIEW_ID_REVIEW_REVIEW_ID` (`review_id`),
  CONSTRAINT `FK_RATING_OPTION_VOTE_OPTION_ID_RATING_OPTION_OPTION_ID` FOREIGN KEY (`option_id`) REFERENCES `rating_option` (`option_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_RATING_OPTION_VOTE_REVIEW_ID_REVIEW_REVIEW_ID` FOREIGN KEY (`review_id`) REFERENCES `review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating option values';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating_option_vote`
--

LOCK TABLES `rating_option_vote` WRITE;
/*!40000 ALTER TABLE `rating_option_vote` DISABLE KEYS */;
/*!40000 ALTER TABLE `rating_option_vote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating_option_vote_aggregated`
--

DROP TABLE IF EXISTS `rating_option_vote_aggregated`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating_option_vote_aggregated` (
  `primary_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Vote aggregation id',
  `rating_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating id',
  `entity_pk_value` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Product id',
  `vote_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Vote dty',
  `vote_value_sum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'General vote sum',
  `percent` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Vote percent',
  `percent_approved` smallint(6) DEFAULT '0' COMMENT 'Vote percent approved by admin',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store Id',
  PRIMARY KEY (`primary_id`),
  KEY `IDX_RATING_OPTION_VOTE_AGGREGATED_RATING_ID` (`rating_id`),
  KEY `IDX_RATING_OPTION_VOTE_AGGREGATED_STORE_ID` (`store_id`),
  CONSTRAINT `FK_RATING_OPT_VOTE_AGGRED_RATING_ID_RATING_RATING_ID` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_RATING_OPT_VOTE_AGGRED_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating vote aggregated';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating_option_vote_aggregated`
--

LOCK TABLES `rating_option_vote_aggregated` WRITE;
/*!40000 ALTER TABLE `rating_option_vote_aggregated` DISABLE KEYS */;
/*!40000 ALTER TABLE `rating_option_vote_aggregated` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating_store`
--

DROP TABLE IF EXISTS `rating_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating_store` (
  `rating_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating id',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store id',
  PRIMARY KEY (`rating_id`,`store_id`),
  KEY `IDX_RATING_STORE_STORE_ID` (`store_id`),
  CONSTRAINT `FK_RATING_STORE_RATING_ID_RATING_RATING_ID` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_RATING_STORE_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating Store';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating_store`
--

LOCK TABLES `rating_store` WRITE;
/*!40000 ALTER TABLE `rating_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `rating_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating_title`
--

DROP TABLE IF EXISTS `rating_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating_title` (
  `rating_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating Id',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store Id',
  `value` varchar(255) NOT NULL COMMENT 'Rating Label',
  PRIMARY KEY (`rating_id`,`store_id`),
  KEY `IDX_RATING_TITLE_STORE_ID` (`store_id`),
  CONSTRAINT `FK_RATING_TITLE_RATING_ID_RATING_RATING_ID` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`rating_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_RATING_TITLE_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating Title';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating_title`
--

LOCK TABLES `rating_title` WRITE;
/*!40000 ALTER TABLE `rating_title` DISABLE KEYS */;
/*!40000 ALTER TABLE `rating_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_compared_product_index`
--

DROP TABLE IF EXISTS `report_compared_product_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_compared_product_index` (
  `index_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Index Id',
  `visitor_id` int(10) unsigned DEFAULT NULL COMMENT 'Visitor Id',
  `customer_id` int(10) unsigned DEFAULT NULL COMMENT 'Customer Id',
  `product_id` int(10) unsigned NOT NULL COMMENT 'Product Id',
  `store_id` smallint(5) unsigned DEFAULT NULL COMMENT 'Store Id',
  `added_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Added At',
  PRIMARY KEY (`index_id`),
  UNIQUE KEY `UNQ_REPORT_COMPARED_PRODUCT_INDEX_VISITOR_ID_PRODUCT_ID` (`visitor_id`,`product_id`),
  UNIQUE KEY `UNQ_REPORT_COMPARED_PRODUCT_INDEX_CUSTOMER_ID_PRODUCT_ID` (`customer_id`,`product_id`),
  KEY `IDX_REPORT_COMPARED_PRODUCT_INDEX_STORE_ID` (`store_id`),
  KEY `IDX_REPORT_COMPARED_PRODUCT_INDEX_ADDED_AT` (`added_at`),
  KEY `IDX_REPORT_COMPARED_PRODUCT_INDEX_PRODUCT_ID` (`product_id`),
  CONSTRAINT `FK_REPORT_CMPD_PRD_IDX_CSTR_ID_CSTR_ENTT_ENTT_ID` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REPORT_CMPD_PRD_IDX_PRD_ID_CAT_PRD_ENTT_ENTT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REPORT_CMPD_PRD_IDX_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Reports Compared Product Index Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_compared_product_index`
--

LOCK TABLES `report_compared_product_index` WRITE;
/*!40000 ALTER TABLE `report_compared_product_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_compared_product_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_event`
--

DROP TABLE IF EXISTS `report_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_event` (
  `event_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Event Id',
  `logged_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Logged At',
  `event_type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Event Type Id',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Object Id',
  `subject_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Subject Id',
  `subtype` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Subtype',
  `store_id` smallint(5) unsigned NOT NULL COMMENT 'Store Id',
  PRIMARY KEY (`event_id`),
  KEY `IDX_REPORT_EVENT_EVENT_TYPE_ID` (`event_type_id`),
  KEY `IDX_REPORT_EVENT_SUBJECT_ID` (`subject_id`),
  KEY `IDX_REPORT_EVENT_OBJECT_ID` (`object_id`),
  KEY `IDX_REPORT_EVENT_SUBTYPE` (`subtype`),
  KEY `IDX_REPORT_EVENT_STORE_ID` (`store_id`),
  CONSTRAINT `FK_7FB0045BED6FAB7156FAC80981D0BBBD` FOREIGN KEY (`event_type_id`) REFERENCES `report_event_types` (`event_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REPORT_EVENT_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=554 DEFAULT CHARSET=utf8 COMMENT='Reports Event Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_event`
--

LOCK TABLES `report_event` WRITE;
/*!40000 ALTER TABLE `report_event` DISABLE KEYS */;
INSERT INTO `report_event` VALUES (1,'2014-10-08 05:28:34',1,1,3,1,1),(2,'2014-10-08 05:28:58',4,1,3,1,1),(3,'2014-10-09 03:49:31',1,1,11,1,1),(4,'2014-10-09 03:50:06',1,1,11,1,1),(5,'2014-10-09 04:15:36',1,1,11,1,1),(6,'2014-10-09 04:29:05',1,2492,11,1,1),(7,'2014-10-09 04:29:14',1,2488,11,1,1),(8,'2014-10-09 04:30:05',1,2488,11,1,1),(9,'2014-10-09 04:31:55',1,2493,11,1,1),(10,'2014-10-09 04:32:14',1,2493,11,1,1),(11,'2014-10-09 04:35:20',1,2493,11,1,1),(12,'2014-10-09 04:38:46',1,2493,11,1,1),(13,'2014-10-09 04:39:53',1,2493,11,1,1),(14,'2014-10-09 04:40:15',4,2493,11,1,1),(15,'2014-10-09 06:45:18',1,2493,13,1,1),(16,'2014-10-09 06:45:33',4,2493,13,1,1),(17,'2014-10-09 06:56:26',1,2488,13,1,1),(18,'2014-10-09 06:56:31',4,2488,13,1,1),(19,'2014-10-09 07:10:07',1,2479,0,1,1),(20,'2014-10-09 07:10:11',1,2491,0,1,1),(21,'2014-10-09 07:10:13',1,2488,0,1,1),(22,'2014-10-09 07:10:17',1,2489,0,1,1),(23,'2014-10-09 07:10:21',1,2490,0,1,1),(24,'2014-10-09 07:10:26',1,2476,0,1,1),(25,'2014-10-09 07:10:29',1,2495,0,1,1),(26,'2014-10-09 07:10:38',1,2475,0,1,1),(27,'2014-10-09 07:10:44',1,2474,0,1,1),(28,'2014-10-09 07:10:47',1,2494,0,1,1),(29,'2014-10-09 07:23:21',1,1,0,1,1),(30,'2014-10-09 07:23:26',1,2492,0,1,1),(31,'2014-10-09 07:23:32',1,2487,0,1,1),(32,'2014-10-09 07:23:37',1,2493,0,1,1),(33,'2014-10-09 08:16:07',1,2494,14,1,1),(34,'2014-10-09 08:18:53',1,2494,14,1,1),(35,'2014-10-09 09:04:38',1,2494,14,1,1),(36,'2014-10-09 09:05:29',1,2494,14,1,1),(37,'2014-10-09 09:06:34',1,2494,14,1,1),(38,'2014-10-09 09:07:10',1,2494,14,1,1),(39,'2014-10-09 09:09:24',1,2494,14,1,1),(40,'2014-10-09 10:09:25',1,2494,14,1,1),(41,'2014-10-09 17:25:59',1,2494,15,1,1),(42,'2014-10-09 17:26:11',4,2494,15,1,1),(43,'2014-10-09 17:26:31',1,2494,15,1,1),(44,'2014-10-09 17:27:18',1,2494,15,1,1),(45,'2014-10-09 17:27:27',4,2494,15,1,1),(46,'2014-10-09 17:35:12',1,2494,15,1,1),(47,'2014-10-09 17:36:14',1,2494,15,1,1),(48,'2014-10-09 17:37:06',1,2549,15,1,1),(49,'2014-10-09 17:38:17',1,2549,15,1,1),(50,'2014-10-09 17:40:04',1,2613,15,1,1),(51,'2014-10-09 17:42:45',1,2613,15,1,1),(52,'2014-10-09 17:42:51',4,2613,15,1,1),(53,'2014-10-09 17:44:26',1,2613,15,1,1),(54,'2014-10-09 17:44:30',1,2613,15,1,1),(55,'2014-10-09 17:45:14',1,2668,15,1,1),(56,'2014-10-09 17:47:13',1,2668,15,1,1),(57,'2014-10-09 17:50:51',1,2668,15,1,1),(58,'2014-10-09 17:52:05',4,2668,15,1,1),(59,'2014-10-09 17:52:19',1,2667,15,1,1),(60,'2014-10-09 17:52:25',4,2667,15,1,1),(61,'2014-10-09 17:57:03',1,2667,15,1,1),(62,'2014-10-09 17:57:06',1,2667,15,1,1),(63,'2014-10-09 18:40:35',1,2685,15,1,1),(64,'2014-10-09 18:42:05',1,2748,15,1,1),(65,'2014-10-09 18:43:47',1,2748,15,1,1),(66,'2014-10-09 18:44:26',1,2748,15,1,1),(67,'2014-10-09 18:44:31',1,2748,15,1,1),(68,'2014-10-09 18:59:52',1,2748,15,1,1),(69,'2014-10-09 19:01:07',1,2743,15,1,1),(70,'2014-10-09 19:01:09',1,2747,0,1,1),(71,'2014-10-09 19:03:22',1,2748,15,1,1),(72,'2014-10-09 19:03:43',1,2743,15,1,1),(73,'2014-10-09 19:05:54',1,2728,15,1,1),(74,'2014-10-09 19:06:28',1,2743,0,1,1),(75,'2014-10-09 19:09:53',4,2728,15,1,1),(76,'2014-10-10 03:52:11',1,2742,0,1,1),(77,'2014-10-10 07:29:13',1,2749,16,1,1),(78,'2014-10-10 10:10:06',1,2726,0,1,1),(79,'2014-10-10 11:13:46',1,2724,0,1,1),(80,'2014-10-10 13:57:27',1,2732,0,1,1),(81,'2014-10-10 15:51:55',1,2745,0,1,1),(82,'2014-10-10 16:56:57',1,2744,0,1,1),(83,'2014-10-10 17:11:56',1,2746,0,1,1),(84,'2014-10-10 17:22:15',1,2721,0,1,1),(85,'2014-10-10 17:22:18',1,2720,0,1,1),(86,'2014-10-10 17:22:23',1,2727,0,1,1),(87,'2014-10-10 17:22:26',1,2698,0,1,1),(88,'2014-10-10 17:22:29',1,2699,0,1,1),(89,'2014-10-10 17:22:31',1,2688,0,1,1),(90,'2014-10-10 17:22:37',1,2725,0,1,1),(91,'2014-10-10 17:22:39',1,2703,0,1,1),(92,'2014-10-10 17:22:48',1,2719,0,1,1),(93,'2014-10-10 17:22:50',1,2700,0,1,1),(94,'2014-10-10 17:22:55',1,2689,0,1,1),(95,'2014-10-10 17:23:00',1,2711,0,1,1),(96,'2014-10-10 17:23:05',1,2730,0,1,1),(97,'2014-10-10 17:23:09',1,2696,0,1,1),(98,'2014-10-10 17:23:11',1,2693,0,1,1),(99,'2014-10-10 17:23:14',1,2695,0,1,1),(100,'2014-10-10 17:23:16',1,2728,0,1,1),(101,'2014-10-10 17:23:20',1,2687,0,1,1),(102,'2014-10-10 17:23:23',1,2694,0,1,1),(103,'2014-10-10 17:23:27',1,2704,0,1,1),(104,'2014-10-10 17:23:29',1,2722,0,1,1),(105,'2014-10-10 17:23:49',1,2697,0,1,1),(106,'2014-10-10 17:23:51',1,2729,0,1,1),(107,'2014-10-10 17:23:53',1,2705,0,1,1),(108,'2014-10-10 17:23:55',1,2709,0,1,1),(109,'2014-10-10 17:23:57',1,2717,0,1,1),(110,'2014-10-10 17:23:59',1,2716,0,1,1),(111,'2014-10-10 17:24:01',1,2708,0,1,1),(112,'2014-10-10 17:24:04',1,2723,0,1,1),(113,'2014-10-10 17:24:06',1,2734,0,1,1),(114,'2014-10-10 17:24:08',1,2713,0,1,1),(115,'2014-10-10 17:24:12',1,2710,0,1,1),(116,'2014-10-10 17:24:14',1,2712,0,1,1),(117,'2014-10-10 17:24:16',1,2706,0,1,1),(118,'2014-10-10 17:24:20',1,2718,0,1,1),(119,'2014-10-10 17:24:22',1,2701,0,1,1),(120,'2014-10-10 17:24:26',1,2702,0,1,1),(121,'2014-10-10 17:24:30',1,2715,0,1,1),(122,'2014-10-10 17:24:32',1,2707,0,1,1),(123,'2014-10-10 17:24:34',1,2714,0,1,1),(124,'2014-10-10 17:24:36',1,2735,0,1,1),(125,'2014-10-10 17:24:38',1,2692,0,1,1),(126,'2014-10-10 17:24:40',1,2691,0,1,1),(127,'2014-10-10 17:24:46',1,2690,0,1,1),(128,'2014-10-10 17:27:46',1,2741,0,1,1),(129,'2014-10-10 17:29:41',1,2740,0,1,1),(130,'2014-10-10 17:30:17',1,2736,0,1,1),(131,'2014-10-10 18:31:59',1,2748,0,1,1),(132,'2014-10-10 19:24:52',1,2731,0,1,1),(133,'2014-10-10 20:40:14',1,2739,0,1,1),(134,'2014-10-10 21:56:01',1,2749,0,1,1),(135,'2014-10-10 22:43:35',1,2738,0,1,1),(136,'2014-10-10 22:44:53',1,2737,0,1,1),(137,'2014-10-10 23:42:15',1,2733,0,1,1),(138,'2014-10-12 10:11:12',1,2691,20,1,1),(139,'2014-10-12 11:51:08',1,2724,0,1,1),(140,'2014-10-12 12:47:20',1,2721,0,1,1),(141,'2014-10-12 14:02:51',1,2720,0,1,1),(142,'2014-10-12 14:59:43',1,2727,0,1,1),(143,'2014-10-12 15:56:33',1,2698,0,1,1),(144,'2014-10-12 16:46:53',1,2699,0,1,1),(145,'2014-10-12 17:54:42',1,2688,0,1,1),(146,'2014-10-12 18:16:55',1,2725,0,1,1),(147,'2014-10-12 18:32:37',1,2703,0,1,1),(148,'2014-10-12 18:51:54',1,2719,0,1,1),(149,'2014-10-12 19:06:53',1,2700,0,1,1),(150,'2014-10-12 20:03:58',1,2689,0,1,1),(151,'2014-10-12 21:19:43',1,2711,0,1,1),(152,'2014-10-12 22:35:32',1,1,0,1,1),(153,'2014-10-12 23:51:18',1,2730,0,1,1),(154,'2014-10-13 00:48:09',1,2696,0,1,1),(155,'2014-10-13 02:03:55',1,2693,0,1,1),(156,'2014-10-13 03:19:44',1,2695,0,1,1),(157,'2014-10-13 04:15:31',1,2749,21,1,1),(158,'2014-10-13 04:15:45',1,2749,21,1,1),(159,'2014-10-13 04:35:33',1,2728,0,1,1),(160,'2014-10-13 04:37:19',1,2749,21,1,1),(161,'2014-10-13 04:39:45',1,2749,21,1,1),(162,'2014-10-13 04:41:13',1,2749,21,1,1),(163,'2014-10-13 05:28:31',1,2749,21,1,1),(164,'2014-10-13 05:48:36',1,2687,0,1,1),(165,'2014-10-13 05:54:33',1,2748,0,1,1),(166,'2014-10-13 06:11:53',1,2694,0,1,1),(167,'2014-10-13 06:17:57',1,2749,21,1,1),(168,'2014-10-13 06:26:51',1,2704,0,1,1),(169,'2014-10-13 06:36:06',1,2743,21,1,1),(170,'2014-10-13 06:41:52',1,2722,0,1,1),(171,'2014-10-13 06:44:47',1,2743,22,1,1),(172,'2014-10-13 06:44:59',1,2743,22,1,1),(173,'2014-10-13 06:53:05',1,2747,0,1,1),(174,'2014-10-13 06:53:20',1,2732,0,1,1),(175,'2014-10-13 06:53:40',1,2745,0,1,1),(176,'2014-10-13 06:53:58',1,2742,0,1,1),(177,'2014-10-13 06:55:04',1,2743,0,1,1),(178,'2014-10-13 06:55:44',1,2744,0,1,1),(179,'2014-10-13 06:56:07',1,2746,0,1,1),(180,'2014-10-13 06:57:23',1,2731,0,1,1),(181,'2014-10-13 06:58:50',1,2749,0,1,1),(182,'2014-10-13 07:17:22',1,2743,21,1,1),(183,'2014-10-13 07:31:55',1,1,0,1,1),(184,'2014-10-13 07:56:01',1,2703,21,1,1),(185,'2014-10-13 07:56:10',1,2749,21,1,1),(186,'2014-10-13 07:56:20',1,2744,21,1,1),(187,'2014-10-13 07:56:29',4,2744,21,1,1),(188,'2014-10-13 08:07:23',1,2743,21,1,1),(189,'2014-10-13 10:25:27',1,2743,0,1,1),(190,'2014-10-13 11:02:01',1,5184,31,1,1),(191,'2014-10-13 11:02:22',4,5184,31,1,1),(192,'2014-10-13 11:16:37',1,4948,0,1,1),(193,'2014-10-13 11:16:51',1,7017,31,1,1),(194,'2014-10-13 11:17:10',1,5506,31,1,1),(195,'2014-10-13 11:18:41',1,5042,31,1,1),(196,'2014-10-13 11:18:51',4,5042,31,1,1),(197,'2014-10-13 11:23:06',1,5017,31,1,1),(198,'2014-10-13 11:23:22',4,5017,31,1,1),(199,'2014-10-13 11:25:38',1,7018,31,1,1),(200,'2014-10-13 11:25:47',1,5017,31,1,1),(201,'2014-10-13 11:26:01',4,5017,31,1,1),(202,'2014-10-13 11:33:35',1,5861,0,1,1),(203,'2014-10-13 11:35:25',1,5189,0,1,1),(204,'2014-10-13 11:41:33',1,5522,0,1,1),(205,'2014-10-13 11:46:31',1,5857,0,1,1),(206,'2014-10-13 11:53:10',1,4896,0,1,1),(207,'2014-10-13 12:22:22',1,4947,0,1,1),(208,'2014-10-13 12:36:56',1,4927,0,1,1),(209,'2014-10-13 12:52:52',1,4899,0,1,1),(210,'2014-10-13 13:17:30',1,4949,0,1,1),(211,'2014-10-13 13:38:12',1,4933,0,1,1),(212,'2014-10-13 14:02:33',1,4945,0,1,1),(213,'2014-10-13 14:16:57',1,4915,0,1,1),(214,'2014-10-13 14:31:56',1,4914,0,1,1),(215,'2014-10-13 14:51:55',1,4932,0,1,1),(216,'2014-10-13 14:52:30',1,6527,0,1,1),(217,'2014-10-13 14:53:23',1,6459,0,1,1),(218,'2014-10-13 14:55:30',1,6293,0,1,1),(219,'2014-10-13 14:58:48',1,6924,0,1,1),(220,'2014-10-13 15:00:12',1,7014,0,1,1),(221,'2014-10-13 15:01:10',1,6923,0,1,1),(222,'2014-10-13 15:02:02',1,6932,0,1,1),(223,'2014-10-13 15:02:47',1,6926,0,1,1),(224,'2014-10-13 15:03:31',1,7012,0,1,1),(225,'2014-10-13 15:03:46',1,6950,0,1,1),(226,'2014-10-13 15:05:18',1,7010,0,1,1),(227,'2014-10-13 15:08:05',1,7009,0,1,1),(228,'2014-10-13 15:08:55',1,7008,0,1,1),(229,'2014-10-13 15:16:51',1,4921,0,1,1),(230,'2014-10-13 15:31:53',1,4936,0,1,1),(231,'2014-10-13 15:55:07',1,4911,0,1,1),(232,'2014-10-13 16:11:58',1,4948,0,1,1),(233,'2014-10-13 16:16:52',1,4934,0,1,1),(234,'2014-10-13 16:47:05',1,4910,0,1,1),(235,'2014-10-13 16:58:31',1,4900,0,1,1),(236,'2014-10-13 17:02:26',1,6813,0,1,1),(237,'2014-10-13 17:05:53',1,4916,0,1,1),(238,'2014-10-13 17:07:49',1,6764,0,1,1),(239,'2014-10-13 17:08:06',1,6757,0,1,1),(240,'2014-10-13 17:14:56',1,4908,0,1,1),(241,'2014-10-13 17:21:54',1,4909,0,1,1),(242,'2014-10-13 17:22:37',1,4947,0,1,1),(243,'2014-10-13 18:16:42',1,4949,0,1,1),(244,'2014-10-13 18:54:40',1,4913,0,1,1),(245,'2014-10-13 18:55:57',1,4901,0,1,1),(246,'2014-10-13 18:57:10',1,4912,0,1,1),(247,'2014-10-13 18:58:25',1,4937,0,1,1),(248,'2014-10-13 18:59:34',1,4898,0,1,1),(249,'2014-10-13 19:00:42',1,4897,0,1,1),(250,'2014-10-13 19:01:48',1,4892,0,1,1),(251,'2014-10-13 19:04:17',1,4926,0,1,1),(252,'2014-10-13 19:07:46',1,4892,0,1,1),(253,'2014-10-13 19:17:03',1,7008,0,1,1),(254,'2014-10-13 20:21:59',1,7010,0,1,1),(255,'2014-10-13 23:37:00',1,4943,0,1,1),(256,'2014-10-14 00:26:32',1,6929,0,1,1),(257,'2014-10-14 00:29:03',1,7018,0,1,1),(258,'2014-10-14 00:34:56',1,6928,0,1,1),(259,'2014-10-14 00:40:37',1,6930,0,1,1),(260,'2014-10-14 00:42:36',1,6931,0,1,1),(261,'2014-10-14 00:43:28',1,6925,0,1,1),(262,'2014-10-14 00:44:01',1,4941,0,1,1),(263,'2014-10-14 00:47:15',1,6922,0,1,1),(264,'2014-10-14 00:47:53',1,4938,0,1,1),(265,'2014-10-14 00:49:40',1,4939,0,1,1),(266,'2014-10-14 00:51:40',1,7019,0,1,1),(267,'2014-10-14 00:53:44',1,7017,0,1,1),(268,'2014-10-14 00:54:36',1,6927,0,1,1),(269,'2014-10-14 00:55:11',1,7011,0,1,1),(270,'2014-10-14 00:55:39',1,7013,0,1,1),(271,'2014-10-14 01:55:06',1,5992,0,1,1),(272,'2014-10-14 01:58:04',1,5990,0,1,1),(273,'2014-10-14 01:58:36',1,5091,0,1,1),(274,'2014-10-14 01:59:17',1,5088,0,1,1),(275,'2014-10-14 01:59:32',1,5188,0,1,1),(276,'2014-10-14 02:01:01',1,5096,0,1,1),(277,'2014-10-14 02:04:30',1,5090,0,1,1),(278,'2014-10-14 02:05:33',1,5092,0,1,1),(279,'2014-10-14 02:08:06',1,5869,0,1,1),(280,'2014-10-14 02:09:51',1,5093,0,1,1),(281,'2014-10-14 02:10:35',1,5097,0,1,1),(282,'2014-10-14 02:15:00',1,5983,0,1,1),(283,'2014-10-14 02:15:43',1,5688,0,1,1),(284,'2014-10-14 02:16:26',1,5991,0,1,1),(285,'2014-10-14 02:17:23',1,5982,0,1,1),(286,'2014-10-14 02:22:12',1,5986,0,1,1),(287,'2014-10-14 02:22:26',1,5187,0,1,1),(288,'2014-10-14 02:31:26',1,5071,0,1,1),(289,'2014-10-14 02:33:12',1,5521,0,1,1),(290,'2014-10-14 02:33:27',1,5859,0,1,1),(291,'2014-10-14 02:33:43',1,5098,0,1,1),(292,'2014-10-14 02:34:22',1,5185,0,1,1),(293,'2014-10-14 02:34:41',1,5984,0,1,1),(294,'2014-10-14 02:34:57',1,5089,0,1,1),(295,'2014-10-14 02:35:25',1,6138,0,1,1),(296,'2014-10-14 02:45:06',1,5095,0,1,1),(297,'2014-10-14 02:45:49',1,5183,0,1,1),(298,'2014-10-14 02:46:20',1,5989,0,1,1),(299,'2014-10-14 02:50:33',1,6133,0,1,1),(300,'2014-10-14 03:01:55',1,5172,0,1,1),(301,'2014-10-14 03:05:28',1,6134,0,1,1),(302,'2014-10-14 03:07:10',1,6135,0,1,1),(303,'2014-10-14 03:07:24',1,5182,0,1,1),(304,'2014-10-14 03:09:24',1,5184,0,1,1),(305,'2014-10-14 03:10:18',1,5866,0,1,1),(306,'2014-10-14 03:14:57',1,5094,0,1,1),(307,'2014-10-14 03:15:56',1,6152,0,1,1),(308,'2014-10-14 03:16:28',1,6141,0,1,1),(309,'2014-10-14 03:22:10',1,5860,0,1,1),(310,'2014-10-14 03:26:22',1,5858,0,1,1),(311,'2014-10-14 03:31:03',1,5864,0,1,1),(312,'2014-10-14 03:32:19',1,6132,0,1,1),(313,'2014-10-14 03:34:57',1,6136,0,1,1),(314,'2014-10-14 03:35:39',1,6140,0,1,1),(315,'2014-10-14 03:36:52',1,5987,0,1,1),(316,'2014-10-14 03:39:45',1,5988,0,1,1),(317,'2014-10-14 03:40:21',1,5985,0,1,1),(318,'2014-10-14 03:42:32',1,5181,0,1,1),(319,'2014-10-14 03:42:48',1,6137,0,1,1),(320,'2014-10-14 03:46:14',1,5865,0,1,1),(321,'2014-10-14 03:46:31',1,6131,0,1,1),(322,'2014-10-14 03:48:34',1,6139,0,1,1),(323,'2014-10-14 03:49:30',1,5867,0,1,1),(324,'2014-10-14 03:50:08',1,5186,0,1,1),(325,'2014-10-14 03:52:23',1,4931,0,1,1),(326,'2014-10-14 03:54:59',1,5868,0,1,1),(327,'2014-10-14 04:56:13',1,5993,0,1,1),(328,'2014-10-14 05:49:22',1,1,0,1,1),(329,'2014-10-14 05:52:03',1,6026,0,1,1),(330,'2014-10-14 06:01:06',1,7012,58,1,1),(331,'2014-10-14 06:06:18',1,6183,0,1,1),(332,'2014-10-14 06:11:40',1,5592,0,1,1),(333,'2014-10-14 06:13:25',1,5612,0,1,1),(334,'2014-10-14 06:14:56',1,5961,0,1,1),(335,'2014-10-14 06:16:17',4,7012,58,1,1),(336,'2014-10-14 06:19:06',1,5925,0,1,1),(337,'2014-10-14 06:21:14',1,5964,0,1,1),(338,'2014-10-14 06:21:29',1,5897,0,1,1),(339,'2014-10-14 06:22:03',1,6812,0,1,1),(340,'2014-10-14 06:25:06',1,4928,0,1,1),(341,'2014-10-14 06:32:05',1,5927,0,1,1),(342,'2014-10-14 06:32:44',1,5591,0,1,1),(343,'2014-10-14 06:35:45',1,6800,0,1,1),(344,'2014-10-14 06:36:54',1,6801,0,1,1),(345,'2014-10-14 06:38:34',1,5956,0,1,1),(346,'2014-10-14 06:40:33',1,5588,0,1,1),(347,'2014-10-14 06:40:50',1,5957,0,1,1),(348,'2014-10-14 06:41:55',1,4947,0,1,1),(349,'2014-10-14 06:44:30',1,5942,0,1,1),(350,'2014-10-14 06:44:46',1,5933,0,1,1),(351,'2014-10-14 06:48:05',1,5926,0,1,1),(352,'2014-10-14 06:49:15',1,5958,0,1,1),(353,'2014-10-14 06:53:05',1,5972,0,1,1),(354,'2014-10-14 06:53:53',1,6075,0,1,1),(355,'2014-10-14 06:57:06',1,5943,0,1,1),(356,'2014-10-14 06:57:48',1,5973,0,1,1),(357,'2014-10-14 06:58:51',1,5053,0,1,1),(358,'2014-10-14 06:59:07',1,5687,0,1,1),(359,'2014-10-14 06:59:53',1,5978,0,1,1),(360,'2014-10-14 07:04:00',1,5669,0,1,1),(361,'2014-10-14 07:04:13',1,5940,0,1,1),(362,'2014-10-14 07:04:48',1,5959,0,1,1),(363,'2014-10-14 07:05:52',1,5054,0,1,1),(364,'2014-10-14 07:08:44',1,5974,0,1,1),(365,'2014-10-14 07:11:29',1,6071,0,1,1),(366,'2014-10-14 07:17:08',1,5941,0,1,1),(367,'2014-10-14 07:17:48',1,5344,0,1,1),(368,'2014-10-14 07:20:13',1,5686,0,1,1),(369,'2014-10-14 07:21:57',1,5820,0,1,1),(370,'2014-10-14 07:22:28',1,6099,0,1,1),(371,'2014-10-14 07:23:06',1,5938,0,1,1),(372,'2014-10-14 07:24:12',1,5589,0,1,1),(373,'2014-10-14 07:26:20',1,5936,0,1,1),(374,'2014-10-14 07:28:36',1,5819,0,1,1),(375,'2014-10-14 07:33:28',1,5977,0,1,1),(376,'2014-10-14 07:39:23',1,5906,0,1,1),(377,'2014-10-14 07:43:37',1,5055,0,1,1),(378,'2014-10-14 07:49:40',1,5856,0,1,1),(379,'2014-10-14 07:51:07',1,6025,0,1,1),(380,'2014-10-14 07:53:36',1,5345,0,1,1),(381,'2014-10-14 07:54:06',1,7017,60,1,1),(382,'2014-10-14 07:54:37',1,4930,60,1,1),(383,'2014-10-14 07:55:48',1,5727,0,1,1),(384,'2014-10-14 07:56:03',1,5863,0,1,1),(385,'2014-10-14 07:56:19',1,6076,0,1,1),(386,'2014-10-14 08:02:39',1,5593,0,1,1),(387,'2014-10-14 08:04:22',1,5904,0,1,1),(388,'2014-10-14 08:06:14',1,5976,0,1,1),(389,'2014-10-14 08:07:36',1,5939,0,1,1),(390,'2014-10-14 08:07:53',1,5971,0,1,1),(391,'2014-10-14 08:08:27',1,5590,0,1,1),(392,'2014-10-14 08:09:43',1,6188,0,1,1),(393,'2014-10-14 08:12:24',1,6187,0,1,1),(394,'2014-10-14 08:13:09',1,5283,0,1,1),(395,'2014-10-14 08:15:43',1,6073,0,1,1),(396,'2014-10-14 08:31:32',1,6793,0,1,1),(397,'2014-10-14 08:32:17',1,5843,0,1,1),(398,'2014-10-14 08:33:13',1,5935,0,1,1),(399,'2014-10-14 08:34:26',1,5594,0,1,1),(400,'2014-10-14 08:35:50',1,5934,0,1,1),(401,'2014-10-14 08:36:58',1,5862,0,1,1),(402,'2014-10-14 08:38:50',1,5851,0,1,1),(403,'2014-10-14 08:44:40',1,5903,0,1,1),(404,'2014-10-14 08:45:49',1,5825,0,1,1),(405,'2014-10-14 08:46:47',1,5670,0,1,1),(406,'2014-10-14 08:52:45',1,6077,0,1,1),(407,'2014-10-14 08:55:44',1,4945,0,1,1),(408,'2014-10-14 08:57:32',1,5960,0,1,1),(409,'2014-10-14 08:57:48',1,5965,0,1,1),(410,'2014-10-14 08:59:30',1,6107,0,1,1),(411,'2014-10-14 08:59:59',1,6104,0,1,1),(412,'2014-10-14 09:04:07',1,6794,0,1,1),(413,'2014-10-14 09:07:14',1,5855,0,1,1),(414,'2014-10-14 09:10:36',1,5258,0,1,1),(415,'2014-10-14 09:12:48',1,5937,0,1,1),(416,'2014-10-14 09:13:46',1,5280,0,1,1),(417,'2014-10-14 09:18:21',1,6067,0,1,1),(418,'2014-10-14 09:20:38',1,6797,0,1,1),(419,'2014-10-14 09:27:22',1,6072,0,1,1),(420,'2014-10-14 09:28:34',1,5818,0,1,1),(421,'2014-10-14 09:29:07',1,5975,0,1,1),(422,'2014-10-14 09:29:41',1,6791,0,1,1),(423,'2014-10-14 09:32:26',1,6795,0,1,1),(424,'2014-10-14 09:34:57',1,5287,0,1,1),(425,'2014-10-14 09:35:27',1,5008,0,1,1),(426,'2014-10-14 09:38:39',1,5847,0,1,1),(427,'2014-10-14 09:38:57',1,5009,0,1,1),(428,'2014-10-14 09:41:30',1,5587,0,1,1),(429,'2014-10-14 09:42:38',1,5284,0,1,1),(430,'2014-10-14 09:43:30',1,5775,0,1,1),(431,'2014-10-14 09:48:06',1,5962,0,1,1),(432,'2014-10-14 09:50:07',1,5842,0,1,1),(433,'2014-10-14 09:50:42',1,5845,0,1,1),(434,'2014-10-14 09:51:41',1,5963,0,1,1),(435,'2014-10-14 09:57:59',1,5955,0,1,1),(436,'2014-10-14 10:00:19',1,5282,0,1,1),(437,'2014-10-14 10:00:54',1,5281,0,1,1),(438,'2014-10-14 10:02:59',1,5035,0,1,1),(439,'2014-10-14 10:07:14',1,5839,0,1,1),(440,'2014-10-14 10:09:52',1,5015,0,1,1),(441,'2014-10-14 10:11:30',1,5902,0,1,1),(442,'2014-10-14 10:14:07',1,5016,0,1,1),(443,'2014-10-14 10:22:24',1,6100,0,1,1),(444,'2014-10-14 10:25:20',1,5286,0,1,1),(445,'2014-10-14 10:28:57',1,6181,0,1,1),(446,'2014-10-14 10:32:04',1,5285,0,1,1),(447,'2014-10-14 10:32:20',1,6101,0,1,1),(448,'2014-10-14 10:38:19',1,6069,0,1,1),(449,'2014-10-14 10:38:37',1,6792,0,1,1),(450,'2014-10-14 10:40:02',1,5013,0,1,1),(451,'2014-10-14 10:40:44',1,5017,0,1,1),(452,'2014-10-14 10:41:59',1,5408,0,1,1),(453,'2014-10-14 10:48:24',1,5586,0,1,1),(454,'2014-10-14 10:51:04',1,5781,0,1,1),(455,'2014-10-14 10:55:14',1,6106,0,1,1),(456,'2014-10-14 10:56:19',1,6102,0,1,1),(457,'2014-10-14 10:59:47',1,5905,0,1,1),(458,'2014-10-14 11:02:15',1,5850,0,1,1),(459,'2014-10-14 11:03:40',1,5010,0,1,1),(460,'2014-10-14 11:05:27',1,5782,0,1,1),(461,'2014-10-14 11:07:45',1,5014,0,1,1),(462,'2014-10-14 11:10:40',1,5785,0,1,1),(463,'2014-10-14 11:12:59',1,6458,0,1,1),(464,'2014-10-14 11:13:35',1,5037,0,1,1),(465,'2014-10-14 11:21:20',1,5783,0,1,1),(466,'2014-10-14 11:26:12',1,6098,0,1,1),(467,'2014-10-14 11:26:58',1,6798,0,1,1),(468,'2014-10-14 11:28:07',1,6068,0,1,1),(469,'2014-10-14 11:30:33',1,5776,0,1,1),(470,'2014-10-14 11:31:37',1,6799,0,1,1),(471,'2014-10-14 11:35:11',1,5043,0,1,1),(472,'2014-10-14 11:37:53',1,5278,0,1,1),(473,'2014-10-14 11:43:18',1,4920,0,1,1),(474,'2014-10-14 11:45:05',1,5018,0,1,1),(475,'2014-10-14 11:47:09',1,5033,0,1,1),(476,'2014-10-14 11:47:47',1,5041,0,1,1),(477,'2014-10-14 11:49:56',1,5012,0,1,1),(478,'2014-10-14 11:50:19',1,5841,0,1,1),(479,'2014-10-14 11:57:26',1,5038,0,1,1),(480,'2014-10-14 11:59:52',1,5849,0,1,1),(481,'2014-10-14 12:00:30',1,5279,0,1,1),(482,'2014-10-14 12:01:18',1,6796,0,1,1),(483,'2014-10-14 12:06:18',1,6454,0,1,1),(484,'2014-10-14 12:09:39',1,6191,0,1,1),(485,'2014-10-14 12:10:58',1,5036,0,1,1),(486,'2014-10-14 12:14:10',1,4946,0,1,1),(487,'2014-10-14 12:15:32',1,5846,0,1,1),(488,'2014-10-14 12:16:32',1,6462,0,1,1),(489,'2014-10-14 12:17:57',1,5848,0,1,1),(490,'2014-10-14 12:18:14',1,5838,0,1,1),(491,'2014-10-14 12:23:13',1,6189,0,1,1),(492,'2014-10-14 12:24:12',1,6070,0,1,1),(493,'2014-10-14 12:25:18',1,6207,0,1,1),(494,'2014-10-14 12:34:55',1,6190,0,1,1),(495,'2014-10-14 12:35:46',1,5410,0,1,1),(496,'2014-10-14 12:36:05',1,6103,0,1,1),(497,'2014-10-14 12:40:56',1,6457,0,1,1),(498,'2014-10-14 12:43:55',1,6460,0,1,1),(499,'2014-10-14 12:45:06',1,6074,0,1,1),(500,'2014-10-14 12:46:30',1,5277,0,1,1),(501,'2014-10-14 12:46:49',1,5444,0,1,1),(502,'2014-10-14 12:51:39',1,5854,0,1,1),(503,'2014-10-14 13:00:43',1,6182,0,1,1),(504,'2014-10-14 13:02:36',1,6437,0,1,1),(505,'2014-10-14 13:05:40',1,6461,0,1,1),(506,'2014-10-14 13:09:10',1,7030,66,1,1),(507,'2014-10-14 13:16:57',1,7031,66,1,1),(508,'2014-10-14 13:17:18',1,7030,66,1,1),(509,'2014-10-14 13:24:17',1,7022,66,1,1),(510,'2014-10-14 13:27:08',1,7022,66,1,1),(511,'2014-10-14 13:30:00',1,7022,66,1,1),(512,'2014-10-14 13:30:05',1,7022,66,1,1),(513,'2014-10-14 13:30:20',1,7022,66,1,1),(514,'2014-10-14 13:33:40',1,7035,66,1,1),(515,'2014-10-14 13:43:59',1,7035,67,1,1),(516,'2014-10-14 13:48:24',1,7035,67,1,1),(517,'2014-10-14 15:37:23',1,7045,0,1,1),(518,'2014-10-14 15:48:28',1,7037,0,1,1),(519,'2014-10-14 16:17:47',1,7044,0,1,1),(520,'2014-10-14 16:24:23',1,7035,0,1,1),(521,'2014-10-14 17:39:46',1,7034,0,1,1),(522,'2014-10-14 17:50:08',1,7040,0,1,1),(523,'2014-10-14 18:05:03',1,7035,72,1,1),(524,'2014-10-14 18:37:12',1,7033,0,1,1),(525,'2014-10-14 20:08:00',1,7039,0,1,1),(526,'2014-10-14 21:12:27',1,7044,0,1,1),(527,'2014-10-14 22:14:16',1,7036,0,1,1),(528,'2014-10-14 23:11:42',1,7038,0,1,1),(529,'2014-10-15 02:28:45',1,7036,0,1,1),(530,'2014-10-15 04:01:40',1,7038,0,1,1),(531,'2014-10-15 07:28:29',1,7039,83,1,1),(532,'2014-10-15 09:20:08',1,7044,84,1,1),(533,'2014-10-15 11:31:18',1,7036,85,1,1),(534,'2014-10-15 12:27:25',1,7045,92,1,1),(535,'2014-10-15 13:04:52',1,7042,96,1,1),(536,'2014-10-15 15:06:37',1,7041,106,1,1),(537,'2014-10-16 00:03:15',1,7037,115,1,1),(538,'2014-10-16 00:10:31',1,7038,117,1,1),(539,'2014-10-16 00:55:30',1,7035,146,1,1),(540,'2014-10-16 01:23:36',1,1,209,1,1),(541,'2014-10-16 01:23:56',1,7045,270,1,1),(542,'2014-10-16 01:23:56',1,7033,271,1,1),(543,'2014-10-16 01:24:01',1,7044,285,1,1),(544,'2014-10-16 01:24:01',1,7043,286,1,1),(545,'2014-10-16 01:24:01',1,7042,287,1,1),(546,'2014-10-16 01:24:01',1,7041,288,1,1),(547,'2014-10-16 01:24:06',1,7040,309,1,1),(548,'2014-10-16 01:24:06',1,7039,310,1,1),(549,'2014-10-16 01:24:07',1,7038,311,1,1),(550,'2014-10-16 01:24:07',1,7034,312,1,1),(551,'2014-10-16 01:24:11',1,7037,332,1,1),(552,'2014-10-16 01:24:12',1,7036,333,1,1),(553,'2014-10-16 01:24:12',1,7035,335,1,1);
/*!40000 ALTER TABLE `report_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_event_types`
--

DROP TABLE IF EXISTS `report_event_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_event_types` (
  `event_type_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Event Type Id',
  `event_name` varchar(64) NOT NULL COMMENT 'Event Name',
  `customer_login` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Customer Login',
  PRIMARY KEY (`event_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='Reports Event Type Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_event_types`
--

LOCK TABLES `report_event_types` WRITE;
/*!40000 ALTER TABLE `report_event_types` DISABLE KEYS */;
INSERT INTO `report_event_types` VALUES (1,'catalog_product_view',0),(2,'sendfriend_product',0),(3,'catalog_product_compare_add_product',0),(4,'checkout_cart_add_product',0),(5,'wishlist_add_product',0),(6,'wishlist_share',0);
/*!40000 ALTER TABLE `report_event_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_viewed_product_aggregated_daily`
--

DROP TABLE IF EXISTS `report_viewed_product_aggregated_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_viewed_product_aggregated_daily` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `period` date DEFAULT NULL COMMENT 'Period',
  `store_id` smallint(5) unsigned DEFAULT NULL COMMENT 'Store Id',
  `product_id` int(10) unsigned DEFAULT NULL COMMENT 'Product Id',
  `product_name` varchar(255) DEFAULT NULL COMMENT 'Product Name',
  `product_price` decimal(12,4) NOT NULL DEFAULT '0.0000' COMMENT 'Product Price',
  `views_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Number of Views',
  `rating_pos` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating Pos',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNQ_REPORT_VIEWED_PRD_AGGRED_DAILY_PERIOD_STORE_ID_PRD_ID` (`period`,`store_id`,`product_id`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_AGGREGATED_DAILY_STORE_ID` (`store_id`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_AGGREGATED_DAILY_PRODUCT_ID` (`product_id`),
  CONSTRAINT `FK_1EF3543D030461BF5D0B6005D17486A5` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_C0A3C4FDE6FF39EC1D4D4EAFCC79B9B9` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Most Viewed Products Aggregated Daily';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_viewed_product_aggregated_daily`
--

LOCK TABLES `report_viewed_product_aggregated_daily` WRITE;
/*!40000 ALTER TABLE `report_viewed_product_aggregated_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_viewed_product_aggregated_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_viewed_product_aggregated_monthly`
--

DROP TABLE IF EXISTS `report_viewed_product_aggregated_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_viewed_product_aggregated_monthly` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `period` date DEFAULT NULL COMMENT 'Period',
  `store_id` smallint(5) unsigned DEFAULT NULL COMMENT 'Store Id',
  `product_id` int(10) unsigned DEFAULT NULL COMMENT 'Product Id',
  `product_name` varchar(255) DEFAULT NULL COMMENT 'Product Name',
  `product_price` decimal(12,4) NOT NULL DEFAULT '0.0000' COMMENT 'Product Price',
  `views_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Number of Views',
  `rating_pos` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating Pos',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNQ_REPORT_VIEWED_PRD_AGGRED_MONTHLY_PERIOD_STORE_ID_PRD_ID` (`period`,`store_id`,`product_id`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_AGGREGATED_MONTHLY_STORE_ID` (`store_id`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_AGGREGATED_MONTHLY_PRODUCT_ID` (`product_id`),
  CONSTRAINT `FK_A2E75A181734B2B0F2888AED6784A7B8` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_F11D1EA64FDB54FD1B2A36F9C3E282F0` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Most Viewed Products Aggregated Monthly';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_viewed_product_aggregated_monthly`
--

LOCK TABLES `report_viewed_product_aggregated_monthly` WRITE;
/*!40000 ALTER TABLE `report_viewed_product_aggregated_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_viewed_product_aggregated_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_viewed_product_aggregated_yearly`
--

DROP TABLE IF EXISTS `report_viewed_product_aggregated_yearly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_viewed_product_aggregated_yearly` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `period` date DEFAULT NULL COMMENT 'Period',
  `store_id` smallint(5) unsigned DEFAULT NULL COMMENT 'Store Id',
  `product_id` int(10) unsigned DEFAULT NULL COMMENT 'Product Id',
  `product_name` varchar(255) DEFAULT NULL COMMENT 'Product Name',
  `product_price` decimal(12,4) NOT NULL DEFAULT '0.0000' COMMENT 'Product Price',
  `views_num` int(11) NOT NULL DEFAULT '0' COMMENT 'Number of Views',
  `rating_pos` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Rating Pos',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNQ_REPORT_VIEWED_PRD_AGGRED_YEARLY_PERIOD_STORE_ID_PRD_ID` (`period`,`store_id`,`product_id`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_AGGREGATED_YEARLY_STORE_ID` (`store_id`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_AGGREGATED_YEARLY_PRODUCT_ID` (`product_id`),
  CONSTRAINT `FK_396A409172FCF1266E16A15CEF86D227` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_8BBFD267A2B27E5164883845EA2F130E` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Most Viewed Products Aggregated Yearly';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_viewed_product_aggregated_yearly`
--

LOCK TABLES `report_viewed_product_aggregated_yearly` WRITE;
/*!40000 ALTER TABLE `report_viewed_product_aggregated_yearly` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_viewed_product_aggregated_yearly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_viewed_product_index`
--

DROP TABLE IF EXISTS `report_viewed_product_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_viewed_product_index` (
  `index_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Index Id',
  `visitor_id` int(10) unsigned DEFAULT NULL COMMENT 'Visitor Id',
  `customer_id` int(10) unsigned DEFAULT NULL COMMENT 'Customer Id',
  `product_id` int(10) unsigned NOT NULL COMMENT 'Product Id',
  `store_id` smallint(5) unsigned DEFAULT NULL COMMENT 'Store Id',
  `added_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Added At',
  PRIMARY KEY (`index_id`),
  UNIQUE KEY `UNQ_REPORT_VIEWED_PRODUCT_INDEX_VISITOR_ID_PRODUCT_ID` (`visitor_id`,`product_id`),
  UNIQUE KEY `UNQ_REPORT_VIEWED_PRODUCT_INDEX_CUSTOMER_ID_PRODUCT_ID` (`customer_id`,`product_id`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_INDEX_STORE_ID` (`store_id`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_INDEX_ADDED_AT` (`added_at`),
  KEY `IDX_REPORT_VIEWED_PRODUCT_INDEX_PRODUCT_ID` (`product_id`),
  CONSTRAINT `FK_REPORT_VIEWED_PRD_IDX_CSTR_ID_CSTR_ENTT_ENTT_ID` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REPORT_VIEWED_PRD_IDX_PRD_ID_CAT_PRD_ENTT_ENTT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REPORT_VIEWED_PRD_IDX_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=538 DEFAULT CHARSET=utf8 COMMENT='Reports Viewed Product Index Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_viewed_product_index`
--

LOCK TABLES `report_viewed_product_index` WRITE;
/*!40000 ALTER TABLE `report_viewed_product_index` DISABLE KEYS */;
INSERT INTO `report_viewed_product_index` VALUES (1,3,1,1,1,'2014-10-08 05:39:33'),(2,11,NULL,1,1,'2014-10-09 04:15:36'),(25,NULL,NULL,1,1,'2014-10-09 07:23:21'),(142,NULL,NULL,1,1,'2014-10-12 22:35:31'),(173,NULL,NULL,1,1,'2014-10-13 07:31:55'),(313,NULL,NULL,1,1,'2014-10-14 05:49:22'),(498,66,NULL,7035,1,'2014-10-14 13:33:40'),(499,67,NULL,7035,1,'2014-10-14 13:48:24'),(501,NULL,NULL,7045,1,'2014-10-14 15:37:23'),(502,NULL,NULL,7037,1,'2014-10-14 15:48:28'),(503,NULL,NULL,7044,1,'2014-10-14 16:17:47'),(504,NULL,NULL,7035,1,'2014-10-14 16:24:23'),(505,NULL,NULL,7034,1,'2014-10-14 17:39:46'),(506,NULL,NULL,7040,1,'2014-10-14 17:50:08'),(507,72,NULL,7035,1,'2014-10-14 18:05:03'),(508,NULL,NULL,7033,1,'2014-10-14 18:37:12'),(509,NULL,NULL,7039,1,'2014-10-14 20:08:00'),(510,NULL,NULL,7044,1,'2014-10-14 21:12:26'),(511,NULL,NULL,7036,1,'2014-10-14 22:14:16'),(512,NULL,NULL,7038,1,'2014-10-14 23:11:42'),(513,NULL,NULL,7036,1,'2014-10-15 02:28:45'),(514,NULL,NULL,7038,1,'2014-10-15 04:01:40'),(515,83,NULL,7039,1,'2014-10-15 07:28:29'),(516,84,NULL,7044,1,'2014-10-15 09:20:08'),(517,85,NULL,7036,1,'2014-10-15 11:31:18'),(518,92,NULL,7045,1,'2014-10-15 12:27:25'),(519,96,NULL,7042,1,'2014-10-15 13:04:52'),(520,106,NULL,7041,1,'2014-10-15 15:06:37'),(521,115,NULL,7037,1,'2014-10-16 00:03:15'),(522,117,NULL,7038,1,'2014-10-16 00:10:31'),(523,146,NULL,7035,1,'2014-10-16 00:55:30'),(524,209,NULL,1,1,'2014-10-16 01:23:35'),(525,270,NULL,7045,1,'2014-10-16 01:23:56'),(526,271,NULL,7033,1,'2014-10-16 01:23:56'),(527,285,NULL,7044,1,'2014-10-16 01:24:01'),(528,286,NULL,7043,1,'2014-10-16 01:24:01'),(529,287,NULL,7042,1,'2014-10-16 01:24:01'),(530,288,NULL,7041,1,'2014-10-16 01:24:01'),(531,309,NULL,7040,1,'2014-10-16 01:24:06'),(532,310,NULL,7039,1,'2014-10-16 01:24:06'),(533,311,NULL,7038,1,'2014-10-16 01:24:07'),(534,312,NULL,7034,1,'2014-10-16 01:24:07'),(535,332,NULL,7037,1,'2014-10-16 01:24:11'),(536,333,NULL,7036,1,'2014-10-16 01:24:12'),(537,335,NULL,7035,1,'2014-10-16 01:24:12');
/*!40000 ALTER TABLE `report_viewed_product_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review` (
  `review_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Review id',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Review create date',
  `entity_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity id',
  `entity_pk_value` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Product id',
  `status_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Status code',
  PRIMARY KEY (`review_id`),
  KEY `IDX_REVIEW_ENTITY_ID` (`entity_id`),
  KEY `IDX_REVIEW_STATUS_ID` (`status_id`),
  KEY `IDX_REVIEW_ENTITY_PK_VALUE` (`entity_pk_value`),
  CONSTRAINT `FK_REVIEW_ENTITY_ID_REVIEW_ENTITY_ENTITY_ID` FOREIGN KEY (`entity_id`) REFERENCES `review_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REVIEW_STATUS_ID_REVIEW_STATUS_STATUS_ID` FOREIGN KEY (`status_id`) REFERENCES `review_status` (`status_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review base information';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_detail`
--

DROP TABLE IF EXISTS `review_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_detail` (
  `detail_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Review detail id',
  `review_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Review id',
  `store_id` smallint(5) unsigned DEFAULT '0' COMMENT 'Store id',
  `title` varchar(255) NOT NULL COMMENT 'Title',
  `detail` text NOT NULL COMMENT 'Detail description',
  `nickname` varchar(128) NOT NULL COMMENT 'User nickname',
  `customer_id` int(10) unsigned DEFAULT NULL COMMENT 'Customer Id',
  PRIMARY KEY (`detail_id`),
  KEY `IDX_REVIEW_DETAIL_REVIEW_ID` (`review_id`),
  KEY `IDX_REVIEW_DETAIL_STORE_ID` (`store_id`),
  KEY `IDX_REVIEW_DETAIL_CUSTOMER_ID` (`customer_id`),
  CONSTRAINT `FK_REVIEW_DETAIL_CUSTOMER_ID_CUSTOMER_ENTITY_ENTITY_ID` FOREIGN KEY (`customer_id`) REFERENCES `customer_entity` (`entity_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_REVIEW_DETAIL_REVIEW_ID_REVIEW_REVIEW_ID` FOREIGN KEY (`review_id`) REFERENCES `review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REVIEW_DETAIL_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review detail information';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_detail`
--

LOCK TABLES `review_detail` WRITE;
/*!40000 ALTER TABLE `review_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_entity`
--

DROP TABLE IF EXISTS `review_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_entity` (
  `entity_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Review entity id',
  `entity_code` varchar(32) NOT NULL COMMENT 'Review entity code',
  PRIMARY KEY (`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Review entities';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_entity`
--

LOCK TABLES `review_entity` WRITE;
/*!40000 ALTER TABLE `review_entity` DISABLE KEYS */;
INSERT INTO `review_entity` VALUES (1,'product'),(2,'customer'),(3,'category');
/*!40000 ALTER TABLE `review_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_entity_summary`
--

DROP TABLE IF EXISTS `review_entity_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_entity_summary` (
  `primary_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Summary review entity id',
  `entity_pk_value` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Product id',
  `entity_type` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Entity type id',
  `reviews_count` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Qty of reviews',
  `rating_summary` smallint(6) NOT NULL DEFAULT '0' COMMENT 'Summarized rating',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store id',
  PRIMARY KEY (`primary_id`),
  KEY `IDX_REVIEW_ENTITY_SUMMARY_STORE_ID` (`store_id`),
  CONSTRAINT `FK_REVIEW_ENTITY_SUMMARY_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review aggregates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_entity_summary`
--

LOCK TABLES `review_entity_summary` WRITE;
/*!40000 ALTER TABLE `review_entity_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_entity_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_status`
--

DROP TABLE IF EXISTS `review_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_status` (
  `status_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Status id',
  `status_code` varchar(32) NOT NULL COMMENT 'Status code',
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Review statuses';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_status`
--

LOCK TABLES `review_status` WRITE;
/*!40000 ALTER TABLE `review_status` DISABLE KEYS */;
INSERT INTO `review_status` VALUES (1,'Approved'),(2,'Pending'),(3,'Not Approved');
/*!40000 ALTER TABLE `review_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_store`
--

DROP TABLE IF EXISTS `review_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_store` (
  `review_id` bigint(20) unsigned NOT NULL COMMENT 'Review Id',
  `store_id` smallint(5) unsigned NOT NULL COMMENT 'Store Id',
  PRIMARY KEY (`review_id`,`store_id`),
  KEY `IDX_REVIEW_STORE_STORE_ID` (`store_id`),
  CONSTRAINT `FK_REVIEW_STORE_REVIEW_ID_REVIEW_REVIEW_ID` FOREIGN KEY (`review_id`) REFERENCES `review` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_REVIEW_STORE_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review Store';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_store`
--

LOCK TABLES `review_store` WRITE;
/*!40000 ALTER TABLE `review_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_store` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-16 16:57:34
