CREATE DATABASE  IF NOT EXISTS `magento_a` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `magento_a`;
-- MySQL dump 10.13  Distrib 5.6.19, for linux-glibc2.5 (x86_64)
--
-- Host: 85.25.84.108    Database: magento_a
-- ------------------------------------------------------
-- Server version	5.5.38-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `captcha_log`
--

DROP TABLE IF EXISTS `captcha_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `captcha_log` (
  `type` varchar(32) NOT NULL COMMENT 'Type',
  `value` varchar(32) NOT NULL COMMENT 'Value',
  `count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Count',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Update Time',
  PRIMARY KEY (`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Count Login Attempts';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `captcha_log`
--

LOCK TABLES `captcha_log` WRITE;
/*!40000 ALTER TABLE `captcha_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `captcha_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_anc_categs_index_idx`
--

DROP TABLE IF EXISTS `catalog_category_anc_categs_index_idx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_anc_categs_index_idx` (
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Category ID',
  `path` varchar(255) DEFAULT NULL COMMENT 'Path',
  KEY `IDX_CATALOG_CATEGORY_ANC_CATEGS_INDEX_IDX_CATEGORY_ID` (`category_id`),
  KEY `IDX_CATALOG_CATEGORY_ANC_CATEGS_INDEX_IDX_PATH_CATEGORY_ID` (`path`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog Category Anchor Indexer Index Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_anc_categs_index_idx`
--

LOCK TABLES `catalog_category_anc_categs_index_idx` WRITE;
/*!40000 ALTER TABLE `catalog_category_anc_categs_index_idx` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_category_anc_categs_index_idx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_anc_categs_index_tmp`
--

DROP TABLE IF EXISTS `catalog_category_anc_categs_index_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_anc_categs_index_tmp` (
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Category ID',
  `path` varchar(255) DEFAULT NULL COMMENT 'Path',
  KEY `IDX_CATALOG_CATEGORY_ANC_CATEGS_INDEX_TMP_CATEGORY_ID` (`category_id`),
  KEY `IDX_CATALOG_CATEGORY_ANC_CATEGS_INDEX_TMP_PATH_CATEGORY_ID` (`path`,`category_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='Catalog Category Anchor Indexer Temp Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_anc_categs_index_tmp`
--

LOCK TABLES `catalog_category_anc_categs_index_tmp` WRITE;
/*!40000 ALTER TABLE `catalog_category_anc_categs_index_tmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_category_anc_categs_index_tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_anc_products_index_idx`
--

DROP TABLE IF EXISTS `catalog_category_anc_products_index_idx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_anc_products_index_idx` (
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Category ID',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Product ID',
  `position` int(10) unsigned DEFAULT NULL COMMENT 'Position',
  KEY `IDX_CAT_CTGR_ANC_PRDS_IDX_IDX_CTGR_ID_PRD_ID_POSITION` (`category_id`,`product_id`,`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog Category Anchor Product Indexer Index Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_anc_products_index_idx`
--

LOCK TABLES `catalog_category_anc_products_index_idx` WRITE;
/*!40000 ALTER TABLE `catalog_category_anc_products_index_idx` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_category_anc_products_index_idx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_anc_products_index_tmp`
--

DROP TABLE IF EXISTS `catalog_category_anc_products_index_tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_anc_products_index_tmp` (
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Category ID',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Product ID',
  `position` int(10) unsigned DEFAULT NULL COMMENT 'Position',
  KEY `IDX_CAT_CTGR_ANC_PRDS_IDX_TMP_CTGR_ID_PRD_ID_POSITION` (`category_id`,`product_id`,`position`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='Catalog Category Anchor Product Indexer Temp Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_anc_products_index_tmp`
--

LOCK TABLES `catalog_category_anc_products_index_tmp` WRITE;
/*!40000 ALTER TABLE `catalog_category_anc_products_index_tmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_category_anc_products_index_tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_entity`
--

DROP TABLE IF EXISTS `catalog_category_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_entity` (
  `entity_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Entity ID',
  `entity_type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity Type ID',
  `attribute_set_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Attriute Set ID',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Parent Category ID',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Creation Time',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Update Time',
  `path` varchar(255) NOT NULL COMMENT 'Tree Path',
  `position` int(11) NOT NULL COMMENT 'Position',
  `level` int(11) NOT NULL DEFAULT '0' COMMENT 'Tree Level',
  `children_count` int(11) NOT NULL COMMENT 'Child Count',
  PRIMARY KEY (`entity_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_LEVEL` (`level`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_PATH_ENTITY_ID` (`path`,`entity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8 COMMENT='Catalog Category Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_entity`
--

LOCK TABLES `catalog_category_entity` WRITE;
/*!40000 ALTER TABLE `catalog_category_entity` DISABLE KEYS */;
INSERT INTO `catalog_category_entity` VALUES (1,3,0,0,'2014-05-15 23:02:15','2014-05-15 23:02:16','1',0,0,1),(2,3,3,1,'2014-05-15 23:02:18','2014-10-13 10:34:09','1/2',1,1,42),(46,3,3,2,'2014-10-13 12:39:25','2014-10-13 10:41:27','1/2/46',1,2,0),(47,3,3,2,'2014-10-13 12:39:25','2014-10-13 10:41:17','1/2/47',2,2,0),(48,3,3,2,'2014-10-13 12:39:26','2014-10-16 01:15:41','1/2/48',3,2,0),(49,3,3,2,'2014-10-13 12:40:03','2014-10-16 01:15:47','1/2/49',4,2,0),(50,3,3,2,'2014-10-13 12:40:03','2014-10-16 01:15:56','1/2/50',5,2,0),(51,3,3,2,'2014-10-13 12:40:03','2014-10-16 01:16:03','1/2/51',6,2,0),(52,3,3,2,'2014-10-13 12:40:04','2014-10-16 01:16:11','1/2/52',7,2,0),(53,3,3,2,'2014-10-13 12:40:04','2014-10-16 01:16:17','1/2/53',8,2,0),(54,3,3,2,'2014-10-13 12:40:06','2014-10-16 01:16:25','1/2/54',9,2,0),(55,3,3,2,'2014-10-13 12:40:06','2014-10-16 01:16:32','1/2/55',10,2,0),(56,3,3,2,'2014-10-13 12:40:06','2014-10-16 01:16:40','1/2/56',11,2,0),(57,3,3,2,'2014-10-13 12:40:06','2014-10-16 01:16:47','1/2/57',12,2,0),(58,3,3,2,'2014-10-13 12:40:06','2014-10-16 01:16:53','1/2/58',13,2,0),(59,3,3,2,'2014-10-13 12:40:06','2014-10-16 01:17:03','1/2/59',14,2,0),(60,3,3,2,'2014-10-13 12:40:07','2014-10-16 01:17:10','1/2/60',15,2,0),(61,3,3,2,'2014-10-13 12:40:07','2014-10-16 01:17:17','1/2/61',16,2,0),(62,3,3,2,'2014-10-13 12:40:07','2014-10-16 01:17:25','1/2/62',17,2,0),(63,3,3,2,'2014-10-13 12:40:07','2014-10-13 12:40:07','1/2/63',18,2,0),(64,3,3,2,'2014-10-13 12:40:07','2014-10-16 01:17:31','1/2/64',19,2,0),(65,3,3,2,'2014-10-13 12:40:08','2014-10-16 01:17:38','1/2/65',20,2,0),(66,3,3,2,'2014-10-13 12:40:08','2014-10-16 01:17:44','1/2/66',21,2,0),(67,3,3,2,'2014-10-13 12:42:07','2014-10-16 01:17:51','1/2/67',22,2,0),(68,3,3,2,'2014-10-13 12:42:09','2014-10-16 01:17:56','1/2/68',23,2,0),(69,3,3,2,'2014-10-13 12:42:11','2014-10-16 01:18:03','1/2/69',24,2,0),(70,3,3,2,'2014-10-13 12:42:20','2014-10-16 01:18:08','1/2/70',25,2,0),(71,3,3,2,'2014-10-13 12:42:40','2014-10-16 01:18:14','1/2/71',26,2,0),(72,3,3,2,'2014-10-13 12:42:41','2014-10-13 12:42:41','1/2/72',27,2,0),(73,3,3,2,'2014-10-13 12:42:46','2014-10-16 01:18:19','1/2/73',28,2,0),(74,3,3,2,'2014-10-13 12:44:56','2014-10-16 01:18:25','1/2/74',29,2,0),(75,3,3,2,'2014-10-13 12:44:56','2014-10-16 01:18:31','1/2/75',30,2,0),(76,3,3,2,'2014-10-13 12:44:57','2014-10-16 01:18:36','1/2/76',31,2,0),(77,3,3,2,'2014-10-13 12:44:57','2014-10-16 01:18:41','1/2/77',32,2,0),(78,3,3,2,'2014-10-13 12:45:02','2014-10-16 01:18:47','1/2/78',33,2,0),(79,3,3,2,'2014-10-13 12:45:03','2014-10-16 01:18:52','1/2/79',34,2,0),(80,3,3,2,'2014-10-13 12:45:20','2014-10-16 01:18:57','1/2/80',35,2,0),(81,3,3,2,'2014-10-13 12:45:22','2014-10-16 01:19:03','1/2/81',36,2,0),(82,3,3,2,'2014-10-13 12:45:22','2014-10-16 01:19:09','1/2/82',37,2,0),(83,3,3,2,'2014-10-13 12:45:23','2014-10-16 01:19:14','1/2/83',38,2,0),(84,3,3,2,'2014-10-13 12:45:23','2014-10-16 01:19:19','1/2/84',39,2,0),(85,3,3,2,'2014-10-13 12:45:35','2014-10-16 01:19:25','1/2/85',40,2,0),(86,3,3,2,'2014-10-13 12:45:40','2014-10-16 01:19:30','1/2/86',41,2,0),(87,3,3,2,'2014-10-13 12:45:49','2014-10-16 01:19:41','1/2/87',42,2,0);
/*!40000 ALTER TABLE `catalog_category_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_entity_datetime`
--

DROP TABLE IF EXISTS `catalog_category_entity_datetime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_entity_datetime` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `entity_type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity Type ID',
  `attribute_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Attribute ID',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `entity_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity ID',
  `value` datetime DEFAULT NULL COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `UNQ_CAT_CTGR_ENTT_DTIME_ENTT_TYPE_ID_ENTT_ID_ATTR_ID_STORE_ID` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_DATETIME_ENTITY_ID` (`entity_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_DATETIME_ATTRIBUTE_ID` (`attribute_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_DATETIME_STORE_ID` (`store_id`),
  CONSTRAINT `FK_CAT_CTGR_ENTT_DTIME_ATTR_ID_EAV_ATTR_ATTR_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_DTIME_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_DTIME_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COMMENT='Catalog Category Datetime Attribute Backend Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_entity_datetime`
--

LOCK TABLES `catalog_category_entity_datetime` WRITE;
/*!40000 ALTER TABLE `catalog_category_entity_datetime` DISABLE KEYS */;
INSERT INTO `catalog_category_entity_datetime` VALUES (1,3,59,0,2,NULL),(2,3,60,0,2,NULL),(3,3,59,0,47,NULL),(4,3,60,0,47,NULL),(5,3,59,0,46,NULL),(6,3,60,0,46,NULL),(7,3,59,0,48,NULL),(8,3,60,0,48,NULL),(9,3,59,0,49,NULL),(10,3,60,0,49,NULL),(11,3,59,0,50,NULL),(12,3,60,0,50,NULL),(13,3,59,0,51,NULL),(14,3,60,0,51,NULL),(15,3,59,0,52,NULL),(16,3,60,0,52,NULL),(17,3,59,0,53,NULL),(18,3,60,0,53,NULL),(19,3,59,0,54,NULL),(20,3,60,0,54,NULL),(21,3,59,0,55,NULL),(22,3,60,0,55,NULL),(23,3,59,0,56,NULL),(24,3,60,0,56,NULL),(25,3,59,0,57,NULL),(26,3,60,0,57,NULL),(27,3,59,0,58,NULL),(28,3,60,0,58,NULL),(29,3,59,0,59,NULL),(30,3,60,0,59,NULL),(31,3,59,0,60,NULL),(32,3,60,0,60,NULL),(33,3,59,0,61,NULL),(34,3,60,0,61,NULL),(35,3,59,0,62,NULL),(36,3,60,0,62,NULL),(37,3,59,0,64,NULL),(38,3,60,0,64,NULL),(39,3,59,0,65,NULL),(40,3,60,0,65,NULL),(41,3,59,0,66,NULL),(42,3,60,0,66,NULL),(43,3,59,0,67,NULL),(44,3,60,0,67,NULL),(45,3,59,0,68,NULL),(46,3,60,0,68,NULL),(47,3,59,0,69,NULL),(48,3,60,0,69,NULL),(49,3,59,0,70,NULL),(50,3,60,0,70,NULL),(51,3,59,0,71,NULL),(52,3,60,0,71,NULL),(53,3,59,0,73,NULL),(54,3,60,0,73,NULL),(55,3,59,0,74,NULL),(56,3,60,0,74,NULL),(57,3,59,0,75,NULL),(58,3,60,0,75,NULL),(59,3,59,0,76,NULL),(60,3,60,0,76,NULL),(61,3,59,0,77,NULL),(62,3,60,0,77,NULL),(63,3,59,0,78,NULL),(64,3,60,0,78,NULL),(65,3,59,0,79,NULL),(66,3,60,0,79,NULL),(67,3,59,0,80,NULL),(68,3,60,0,80,NULL),(69,3,59,0,81,NULL),(70,3,60,0,81,NULL),(71,3,59,0,82,NULL),(72,3,60,0,82,NULL),(73,3,59,0,83,NULL),(74,3,60,0,83,NULL),(75,3,59,0,84,NULL),(76,3,60,0,84,NULL),(77,3,59,0,85,NULL),(78,3,60,0,85,NULL),(79,3,59,0,86,NULL),(80,3,60,0,86,NULL),(81,3,59,0,87,NULL),(82,3,60,0,87,NULL);
/*!40000 ALTER TABLE `catalog_category_entity_datetime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_entity_decimal`
--

DROP TABLE IF EXISTS `catalog_category_entity_decimal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_entity_decimal` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `entity_type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity Type ID',
  `attribute_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Attribute ID',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `entity_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity ID',
  `value` decimal(12,4) DEFAULT NULL COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `UNQ_CAT_CTGR_ENTT_DEC_ENTT_TYPE_ID_ENTT_ID_ATTR_ID_STORE_ID` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_DECIMAL_ENTITY_ID` (`entity_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_DECIMAL_ATTRIBUTE_ID` (`attribute_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_DECIMAL_STORE_ID` (`store_id`),
  CONSTRAINT `FK_CAT_CTGR_ENTT_DEC_ATTR_ID_EAV_ATTR_ATTR_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_DEC_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_DEC_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COMMENT='Catalog Category Decimal Attribute Backend Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_entity_decimal`
--

LOCK TABLES `catalog_category_entity_decimal` WRITE;
/*!40000 ALTER TABLE `catalog_category_entity_decimal` DISABLE KEYS */;
INSERT INTO `catalog_category_entity_decimal` VALUES (1,3,70,0,2,NULL),(2,3,70,0,47,NULL),(3,3,70,0,46,NULL),(4,3,70,0,48,NULL),(5,3,70,0,49,NULL),(6,3,70,0,50,NULL),(7,3,70,0,51,NULL),(8,3,70,0,52,NULL),(9,3,70,0,53,NULL),(10,3,70,0,54,NULL),(11,3,70,0,55,NULL),(12,3,70,0,56,NULL),(13,3,70,0,57,NULL),(14,3,70,0,58,NULL),(15,3,70,0,59,NULL),(16,3,70,0,60,NULL),(17,3,70,0,61,NULL),(18,3,70,0,62,NULL),(19,3,70,0,64,NULL),(20,3,70,0,65,NULL),(21,3,70,0,66,NULL),(22,3,70,0,67,NULL),(23,3,70,0,68,NULL),(24,3,70,0,69,NULL),(25,3,70,0,70,NULL),(26,3,70,0,71,NULL),(27,3,70,0,73,NULL),(28,3,70,0,74,NULL),(29,3,70,0,75,NULL),(30,3,70,0,76,NULL),(31,3,70,0,77,NULL),(32,3,70,0,78,NULL),(33,3,70,0,79,NULL),(34,3,70,0,80,NULL),(35,3,70,0,81,NULL),(36,3,70,0,82,NULL),(37,3,70,0,83,NULL),(38,3,70,0,84,NULL),(39,3,70,0,85,NULL),(40,3,70,0,86,NULL),(41,3,70,0,87,NULL);
/*!40000 ALTER TABLE `catalog_category_entity_decimal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_entity_int`
--

DROP TABLE IF EXISTS `catalog_category_entity_int`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_entity_int` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `entity_type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity Type ID',
  `attribute_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Attribute ID',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `entity_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity ID',
  `value` int(11) DEFAULT NULL COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `UNQ_CAT_CTGR_ENTT_INT_ENTT_TYPE_ID_ENTT_ID_ATTR_ID_STORE_ID` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_INT_ENTITY_ID` (`entity_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_INT_ATTRIBUTE_ID` (`attribute_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_INT_STORE_ID` (`store_id`),
  CONSTRAINT `FK_CAT_CTGR_ENTT_INT_ATTR_ID_EAV_ATTR_ATTR_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_INT_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_INT_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=426 DEFAULT CHARSET=utf8 COMMENT='Catalog Category Integer Attribute Backend Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_entity_int`
--

LOCK TABLES `catalog_category_entity_int` WRITE;
/*!40000 ALTER TABLE `catalog_category_entity_int` DISABLE KEYS */;
INSERT INTO `catalog_category_entity_int` VALUES (1,3,67,0,1,1),(2,3,67,1,1,1),(3,3,42,0,2,0),(4,3,67,0,2,1),(6,3,67,1,2,1),(136,3,50,0,2,NULL),(137,3,51,0,2,0),(138,3,69,0,2,0),(140,3,42,0,46,1),(141,3,51,0,46,1),(142,3,67,0,46,0),(143,3,42,0,47,1),(144,3,51,0,47,1),(145,3,67,0,47,0),(146,3,42,0,48,1),(147,3,51,0,48,1),(148,3,67,0,48,0),(149,3,42,0,49,1),(150,3,51,0,49,1),(151,3,67,0,49,0),(152,3,42,0,50,1),(153,3,51,0,50,1),(154,3,67,0,50,0),(155,3,42,0,51,1),(156,3,51,0,51,1),(157,3,67,0,51,0),(158,3,42,0,52,1),(159,3,51,0,52,1),(160,3,67,0,52,0),(161,3,42,0,53,1),(162,3,51,0,53,1),(163,3,67,0,53,0),(164,3,42,0,54,1),(165,3,51,0,54,1),(166,3,67,0,54,0),(167,3,42,0,55,1),(168,3,51,0,55,1),(169,3,67,0,55,0),(170,3,42,0,56,1),(171,3,51,0,56,1),(172,3,67,0,56,0),(173,3,42,0,57,1),(174,3,51,0,57,1),(175,3,67,0,57,0),(176,3,42,0,58,1),(177,3,51,0,58,1),(178,3,67,0,58,0),(179,3,42,0,59,1),(180,3,51,0,59,1),(181,3,67,0,59,0),(182,3,42,0,60,1),(183,3,51,0,60,1),(184,3,67,0,60,0),(185,3,42,0,61,1),(186,3,51,0,61,1),(187,3,67,0,61,0),(188,3,42,0,62,1),(189,3,51,0,62,1),(190,3,67,0,62,0),(191,3,42,0,63,1),(192,3,51,0,63,1),(193,3,67,0,63,1),(194,3,42,0,64,1),(195,3,51,0,64,1),(196,3,67,0,64,0),(197,3,42,0,65,1),(198,3,51,0,65,1),(199,3,67,0,65,0),(200,3,42,0,66,1),(201,3,51,0,66,1),(202,3,67,0,66,0),(203,3,50,0,47,NULL),(204,3,68,0,47,0),(205,3,69,0,47,0),(207,3,50,0,46,NULL),(208,3,68,0,46,0),(209,3,69,0,46,0),(211,3,42,0,67,1),(212,3,51,0,67,1),(213,3,67,0,67,0),(214,3,42,0,68,1),(215,3,51,0,68,1),(216,3,67,0,68,0),(217,3,42,0,69,1),(218,3,51,0,69,1),(219,3,67,0,69,0),(220,3,42,0,70,1),(221,3,51,0,70,1),(222,3,67,0,70,0),(223,3,42,0,71,1),(224,3,51,0,71,1),(225,3,67,0,71,0),(226,3,42,0,72,1),(227,3,51,0,72,1),(228,3,67,0,72,1),(229,3,42,0,73,1),(230,3,51,0,73,1),(231,3,67,0,73,0),(232,3,42,0,74,1),(233,3,51,0,74,1),(234,3,67,0,74,0),(235,3,42,0,75,1),(236,3,51,0,75,1),(237,3,67,0,75,0),(238,3,42,0,76,1),(239,3,51,0,76,1),(240,3,67,0,76,0),(241,3,42,0,77,1),(242,3,51,0,77,1),(243,3,67,0,77,0),(244,3,42,0,78,1),(245,3,51,0,78,1),(246,3,67,0,78,0),(247,3,42,0,79,1),(248,3,51,0,79,1),(249,3,67,0,79,0),(250,3,42,0,80,1),(251,3,51,0,80,1),(252,3,67,0,80,0),(253,3,42,0,81,1),(254,3,51,0,81,1),(255,3,67,0,81,0),(256,3,42,0,82,1),(257,3,51,0,82,1),(258,3,67,0,82,0),(259,3,42,0,83,1),(260,3,51,0,83,1),(261,3,67,0,83,0),(262,3,42,0,84,1),(263,3,51,0,84,1),(264,3,67,0,84,0),(265,3,42,0,85,1),(266,3,51,0,85,1),(267,3,67,0,85,0),(268,3,42,0,86,1),(269,3,51,0,86,1),(270,3,67,0,86,0),(271,3,42,0,87,1),(272,3,51,0,87,1),(273,3,67,0,87,0),(274,3,50,0,48,NULL),(275,3,68,0,48,0),(276,3,69,0,48,0),(278,3,50,0,49,NULL),(279,3,68,0,49,0),(280,3,69,0,49,0),(282,3,50,0,50,NULL),(283,3,68,0,50,0),(284,3,69,0,50,0),(286,3,50,0,51,NULL),(287,3,68,0,51,0),(288,3,69,0,51,0),(290,3,50,0,52,NULL),(291,3,68,0,52,0),(292,3,69,0,52,0),(294,3,50,0,53,NULL),(295,3,68,0,53,0),(296,3,69,0,53,0),(298,3,50,0,54,NULL),(299,3,68,0,54,0),(300,3,69,0,54,0),(302,3,50,0,55,NULL),(303,3,68,0,55,0),(304,3,69,0,55,0),(306,3,50,0,56,NULL),(307,3,68,0,56,0),(308,3,69,0,56,0),(310,3,50,0,57,NULL),(311,3,68,0,57,0),(312,3,69,0,57,0),(314,3,50,0,58,NULL),(315,3,68,0,58,0),(316,3,69,0,58,0),(318,3,50,0,59,NULL),(319,3,68,0,59,0),(320,3,69,0,59,0),(322,3,50,0,60,NULL),(323,3,68,0,60,0),(324,3,69,0,60,0),(326,3,50,0,61,NULL),(327,3,68,0,61,0),(328,3,69,0,61,0),(330,3,50,0,62,NULL),(331,3,68,0,62,0),(332,3,69,0,62,0),(334,3,50,0,64,NULL),(335,3,68,0,64,0),(336,3,69,0,64,0),(338,3,50,0,65,NULL),(339,3,68,0,65,0),(340,3,69,0,65,0),(342,3,50,0,66,NULL),(343,3,68,0,66,0),(344,3,69,0,66,0),(346,3,50,0,67,NULL),(347,3,68,0,67,0),(348,3,69,0,67,0),(350,3,50,0,68,NULL),(351,3,68,0,68,0),(352,3,69,0,68,0),(354,3,50,0,69,NULL),(355,3,68,0,69,0),(356,3,69,0,69,0),(358,3,50,0,70,NULL),(359,3,68,0,70,0),(360,3,69,0,70,0),(362,3,50,0,71,NULL),(363,3,68,0,71,0),(364,3,69,0,71,0),(366,3,50,0,73,NULL),(367,3,68,0,73,0),(368,3,69,0,73,0),(370,3,50,0,74,NULL),(371,3,68,0,74,0),(372,3,69,0,74,0),(374,3,50,0,75,NULL),(375,3,68,0,75,0),(376,3,69,0,75,0),(378,3,50,0,76,NULL),(379,3,68,0,76,0),(380,3,69,0,76,0),(382,3,50,0,77,NULL),(383,3,68,0,77,0),(384,3,69,0,77,0),(386,3,50,0,78,NULL),(387,3,68,0,78,0),(388,3,69,0,78,0),(390,3,50,0,79,NULL),(391,3,68,0,79,0),(392,3,69,0,79,0),(394,3,50,0,80,NULL),(395,3,68,0,80,0),(396,3,69,0,80,0),(398,3,50,0,81,NULL),(399,3,68,0,81,0),(400,3,69,0,81,0),(402,3,50,0,82,NULL),(403,3,68,0,82,0),(404,3,69,0,82,0),(406,3,50,0,83,NULL),(407,3,68,0,83,0),(408,3,69,0,83,0),(410,3,50,0,84,NULL),(411,3,68,0,84,0),(412,3,69,0,84,0),(414,3,50,0,85,NULL),(415,3,68,0,85,0),(416,3,69,0,85,0),(418,3,50,0,86,NULL),(419,3,68,0,86,0),(420,3,69,0,86,0),(422,3,50,0,87,NULL),(423,3,68,0,87,0),(424,3,69,0,87,0);
/*!40000 ALTER TABLE `catalog_category_entity_int` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_entity_text`
--

DROP TABLE IF EXISTS `catalog_category_entity_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_entity_text` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `entity_type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity Type ID',
  `attribute_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Attribute ID',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `entity_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity ID',
  `value` text COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `UNQ_CAT_CTGR_ENTT_TEXT_ENTT_TYPE_ID_ENTT_ID_ATTR_ID_STORE_ID` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_TEXT_ENTITY_ID` (`entity_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_TEXT_ATTRIBUTE_ID` (`attribute_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_TEXT_STORE_ID` (`store_id`),
  CONSTRAINT `FK_CAT_CTGR_ENTT_TEXT_ATTR_ID_EAV_ATTR_ATTR_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_TEXT_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_TEXT_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8 COMMENT='Catalog Category Text Attribute Backend Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_entity_text`
--

LOCK TABLES `catalog_category_entity_text` WRITE;
/*!40000 ALTER TABLE `catalog_category_entity_text` DISABLE KEYS */;
INSERT INTO `catalog_category_entity_text` VALUES (1,3,65,0,1,NULL),(2,3,65,1,1,NULL),(3,3,65,0,2,NULL),(5,3,44,0,2,NULL),(6,3,47,0,2,NULL),(7,3,48,0,2,NULL),(8,3,62,0,2,NULL),(10,3,44,0,47,NULL),(11,3,47,0,47,NULL),(12,3,48,0,47,NULL),(13,3,62,0,47,NULL),(14,3,65,0,47,NULL),(15,3,44,0,46,NULL),(16,3,47,0,46,NULL),(17,3,48,0,46,NULL),(18,3,62,0,46,NULL),(19,3,65,0,46,NULL),(20,3,44,0,48,NULL),(21,3,47,0,48,NULL),(22,3,48,0,48,NULL),(23,3,62,0,48,NULL),(24,3,65,0,48,NULL),(25,3,44,0,49,NULL),(26,3,47,0,49,NULL),(27,3,48,0,49,NULL),(28,3,62,0,49,NULL),(29,3,65,0,49,NULL),(30,3,44,0,50,NULL),(31,3,47,0,50,NULL),(32,3,48,0,50,NULL),(33,3,62,0,50,NULL),(34,3,65,0,50,NULL),(35,3,44,0,51,NULL),(36,3,47,0,51,NULL),(37,3,48,0,51,NULL),(38,3,62,0,51,NULL),(39,3,65,0,51,NULL),(40,3,44,0,52,NULL),(41,3,47,0,52,NULL),(42,3,48,0,52,NULL),(43,3,62,0,52,NULL),(44,3,65,0,52,NULL),(45,3,44,0,53,NULL),(46,3,47,0,53,NULL),(47,3,48,0,53,NULL),(48,3,62,0,53,NULL),(49,3,65,0,53,NULL),(50,3,44,0,54,NULL),(51,3,47,0,54,NULL),(52,3,48,0,54,NULL),(53,3,62,0,54,NULL),(54,3,65,0,54,NULL),(55,3,44,0,55,NULL),(56,3,47,0,55,NULL),(57,3,48,0,55,NULL),(58,3,62,0,55,NULL),(59,3,65,0,55,NULL),(60,3,44,0,56,NULL),(61,3,47,0,56,NULL),(62,3,48,0,56,NULL),(63,3,62,0,56,NULL),(64,3,65,0,56,NULL),(65,3,44,0,57,NULL),(66,3,47,0,57,NULL),(67,3,48,0,57,NULL),(68,3,62,0,57,NULL),(69,3,65,0,57,NULL),(70,3,44,0,58,NULL),(71,3,47,0,58,NULL),(72,3,48,0,58,NULL),(73,3,62,0,58,NULL),(74,3,65,0,58,NULL),(75,3,44,0,59,NULL),(76,3,47,0,59,NULL),(77,3,48,0,59,NULL),(78,3,62,0,59,NULL),(79,3,65,0,59,NULL),(80,3,44,0,60,NULL),(81,3,47,0,60,NULL),(82,3,48,0,60,NULL),(83,3,62,0,60,NULL),(84,3,65,0,60,NULL),(85,3,44,0,61,NULL),(86,3,47,0,61,NULL),(87,3,48,0,61,NULL),(88,3,62,0,61,NULL),(89,3,65,0,61,NULL),(90,3,44,0,62,NULL),(91,3,47,0,62,NULL),(92,3,48,0,62,NULL),(93,3,62,0,62,NULL),(94,3,65,0,62,NULL),(95,3,44,0,64,NULL),(96,3,47,0,64,NULL),(97,3,48,0,64,NULL),(98,3,62,0,64,NULL),(99,3,65,0,64,NULL),(100,3,44,0,65,NULL),(101,3,47,0,65,NULL),(102,3,48,0,65,NULL),(103,3,62,0,65,NULL),(104,3,65,0,65,NULL),(105,3,44,0,66,NULL),(106,3,47,0,66,NULL),(107,3,48,0,66,NULL),(108,3,62,0,66,NULL),(109,3,65,0,66,NULL),(110,3,44,0,67,NULL),(111,3,47,0,67,NULL),(112,3,48,0,67,NULL),(113,3,62,0,67,NULL),(114,3,65,0,67,NULL),(115,3,44,0,68,NULL),(116,3,47,0,68,NULL),(117,3,48,0,68,NULL),(118,3,62,0,68,NULL),(119,3,65,0,68,NULL),(120,3,44,0,69,NULL),(121,3,47,0,69,NULL),(122,3,48,0,69,NULL),(123,3,62,0,69,NULL),(124,3,65,0,69,NULL),(125,3,44,0,70,NULL),(126,3,47,0,70,NULL),(127,3,48,0,70,NULL),(128,3,62,0,70,NULL),(129,3,65,0,70,NULL),(130,3,44,0,71,NULL),(131,3,47,0,71,NULL),(132,3,48,0,71,NULL),(133,3,62,0,71,NULL),(134,3,65,0,71,NULL),(135,3,44,0,73,NULL),(136,3,47,0,73,NULL),(137,3,48,0,73,NULL),(138,3,62,0,73,NULL),(139,3,65,0,73,NULL),(140,3,44,0,74,NULL),(141,3,47,0,74,NULL),(142,3,48,0,74,NULL),(143,3,62,0,74,NULL),(144,3,65,0,74,NULL),(145,3,44,0,75,NULL),(146,3,47,0,75,NULL),(147,3,48,0,75,NULL),(148,3,62,0,75,NULL),(149,3,65,0,75,NULL),(150,3,44,0,76,NULL),(151,3,47,0,76,NULL),(152,3,48,0,76,NULL),(153,3,62,0,76,NULL),(154,3,65,0,76,NULL),(155,3,44,0,77,NULL),(156,3,47,0,77,NULL),(157,3,48,0,77,NULL),(158,3,62,0,77,NULL),(159,3,65,0,77,NULL),(160,3,44,0,78,NULL),(161,3,47,0,78,NULL),(162,3,48,0,78,NULL),(163,3,62,0,78,NULL),(164,3,65,0,78,NULL),(165,3,44,0,79,NULL),(166,3,47,0,79,NULL),(167,3,48,0,79,NULL),(168,3,62,0,79,NULL),(169,3,65,0,79,NULL),(170,3,44,0,80,NULL),(171,3,47,0,80,NULL),(172,3,48,0,80,NULL),(173,3,62,0,80,NULL),(174,3,65,0,80,NULL),(175,3,44,0,81,NULL),(176,3,47,0,81,NULL),(177,3,48,0,81,NULL),(178,3,62,0,81,NULL),(179,3,65,0,81,NULL),(180,3,44,0,82,NULL),(181,3,47,0,82,NULL),(182,3,48,0,82,NULL),(183,3,62,0,82,NULL),(184,3,65,0,82,NULL),(185,3,44,0,83,NULL),(186,3,47,0,83,NULL),(187,3,48,0,83,NULL),(188,3,62,0,83,NULL),(189,3,65,0,83,NULL),(190,3,44,0,84,NULL),(191,3,47,0,84,NULL),(192,3,48,0,84,NULL),(193,3,62,0,84,NULL),(194,3,65,0,84,NULL),(195,3,44,0,85,NULL),(196,3,47,0,85,NULL),(197,3,48,0,85,NULL),(198,3,62,0,85,NULL),(199,3,65,0,85,NULL),(200,3,44,0,86,NULL),(201,3,47,0,86,NULL),(202,3,48,0,86,NULL),(203,3,62,0,86,NULL),(204,3,65,0,86,NULL),(205,3,44,0,87,NULL),(206,3,47,0,87,NULL),(207,3,48,0,87,NULL),(208,3,62,0,87,NULL),(209,3,65,0,87,NULL);
/*!40000 ALTER TABLE `catalog_category_entity_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_entity_varchar`
--

DROP TABLE IF EXISTS `catalog_category_entity_varchar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_entity_varchar` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Value ID',
  `entity_type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity Type ID',
  `attribute_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Attribute ID',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `entity_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Entity ID',
  `value` varchar(255) DEFAULT NULL COMMENT 'Value',
  PRIMARY KEY (`value_id`),
  UNIQUE KEY `UNQ_CAT_CTGR_ENTT_VCHR_ENTT_TYPE_ID_ENTT_ID_ATTR_ID_STORE_ID` (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_VARCHAR_ENTITY_ID` (`entity_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_VARCHAR_ATTRIBUTE_ID` (`attribute_id`),
  KEY `IDX_CATALOG_CATEGORY_ENTITY_VARCHAR_STORE_ID` (`store_id`),
  CONSTRAINT `FK_CAT_CTGR_ENTT_VCHR_ATTR_ID_EAV_ATTR_ATTR_ID` FOREIGN KEY (`attribute_id`) REFERENCES `eav_attribute` (`attribute_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_VCHR_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_ENTT_VCHR_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=426 DEFAULT CHARSET=utf8 COMMENT='Catalog Category Varchar Attribute Backend Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_entity_varchar`
--

LOCK TABLES `catalog_category_entity_varchar` WRITE;
/*!40000 ALTER TABLE `catalog_category_entity_varchar` DISABLE KEYS */;
INSERT INTO `catalog_category_entity_varchar` VALUES (1,3,41,0,1,'Root Catalog'),(2,3,41,1,1,'Root Catalog'),(3,3,43,1,1,'root-catalog'),(4,3,41,0,2,'Default Category'),(5,3,41,1,2,'Default Category'),(6,3,49,1,2,'PRODUCTS'),(7,3,43,1,2,'default-category'),(137,3,46,0,2,NULL),(138,3,58,0,2,NULL),(139,3,61,0,2,NULL),(140,3,41,0,46,'abonnement'),(141,3,43,0,46,'abonnement'),(142,3,57,0,46,'abonnement.html'),(143,3,41,0,47,'automobil-club-mitgliedschaft'),(144,3,43,0,47,'automobil-club-mitgliedschaft'),(145,3,57,0,47,'automobil-club-mitgliedschaft.html'),(146,3,41,0,48,'bankkonto'),(147,3,43,0,48,'bankkonto'),(148,3,57,0,48,'bankkonto.html'),(149,3,41,0,49,'berufsunfaehigkeitsversicherung'),(150,3,43,0,49,'berufsunfaehigkeitsversicherung'),(151,3,57,0,49,'berufsunfaehigkeitsversicherung.html'),(152,3,41,0,50,'bus-bahn-ticket'),(153,3,43,0,50,'bus-bahn-ticket'),(154,3,57,0,50,'bus-bahn-ticket.html'),(155,3,41,0,51,'energie'),(156,3,43,0,51,'energie'),(157,3,57,0,51,'energie.html'),(158,3,41,0,52,'haftpflichtversicherung'),(159,3,43,0,52,'haftpflichtversicherung'),(160,3,57,0,52,'haftpflichtversicherung.html'),(161,3,41,0,53,'fitnessstudio'),(162,3,43,0,53,'fitnessstudio'),(163,3,57,0,53,'fitnessstudio.html'),(164,3,41,0,54,'hausratversicherung'),(165,3,43,0,54,'hausratversicherung'),(166,3,57,0,54,'hausratversicherung.html'),(167,3,41,0,55,'kfz-versicherung'),(168,3,43,0,55,'kfz-versicherung'),(169,3,57,0,55,'kfz-versicherung.html'),(170,3,41,0,56,'krankenversicherung'),(171,3,43,0,56,'krankenversicherung'),(172,3,57,0,56,'krankenversicherung.html'),(173,3,41,0,57,'mitgliedschaft'),(174,3,43,0,57,'mitgliedschaft'),(175,3,57,0,57,'mitgliedschaft.html'),(176,3,41,0,58,'online-dienst'),(177,3,43,0,58,'online-dienst'),(178,3,57,0,58,'online-dienst.html'),(179,3,41,0,59,'reiseversicherung'),(180,3,43,0,59,'reiseversicherung'),(181,3,57,0,59,'reiseversicherung.html'),(182,3,41,0,60,'sonstige'),(183,3,43,0,60,'sonstige'),(184,3,57,0,60,'sonstige.html'),(185,3,41,0,61,'zeitschrift'),(186,3,43,0,61,'zeitschrift'),(187,3,57,0,61,'zeitschrift.html'),(188,3,41,0,62,'zeitung'),(189,3,43,0,62,'zeitung'),(190,3,57,0,62,'zeitung.html'),(191,3,41,0,63,'handyvertrag'),(192,3,43,0,63,'handyvertrag'),(193,3,57,0,63,'handyvertrag.html'),(194,3,41,0,64,'rechtsschutzversicherung'),(195,3,43,0,64,'rechtsschutzversicherung'),(196,3,57,0,64,'rechtsschutzversicherung.html'),(197,3,41,0,65,'rentenversicherung'),(198,3,43,0,65,'rentenversicherung'),(199,3,57,0,65,'rentenversicherung.html'),(200,3,41,0,66,'versicherung'),(201,3,43,0,66,'versicherung'),(202,3,57,0,66,'versicherung.html'),(203,3,46,0,47,NULL),(204,3,49,0,47,'PRODUCTS'),(205,3,58,0,47,NULL),(206,3,61,0,47,NULL),(207,3,46,0,46,NULL),(208,3,49,0,46,'PRODUCTS'),(209,3,58,0,46,NULL),(210,3,61,0,46,NULL),(211,3,41,0,67,'bausparvertrag'),(212,3,43,0,67,'bausparvertrag'),(213,3,57,0,67,'bausparvertrag.html'),(214,3,41,0,68,'buch-download'),(215,3,43,0,68,'buch-download'),(216,3,57,0,68,'buch-download.html'),(217,3,41,0,69,'domain'),(218,3,43,0,69,'domain'),(219,3,57,0,69,'domain.html'),(220,3,41,0,70,'finanzen'),(221,3,43,0,70,'finanzen'),(222,3,57,0,70,'finanzen.html'),(223,3,41,0,71,'hilfsorganisation'),(224,3,43,0,71,'hilfsorganisation'),(225,3,57,0,71,'hilfsorganisation.html'),(226,3,41,0,72,'internet-und-telefon'),(227,3,43,0,72,'internet-und-telefon'),(228,3,57,0,72,'internet-und-telefon.html'),(229,3,41,0,73,'kabelanschluss'),(230,3,43,0,73,'kabelanschluss'),(231,3,57,0,73,'kabelanschluss.html'),(232,3,41,0,74,'musik-streaming'),(233,3,43,0,74,'musik-streaming'),(234,3,57,0,74,'musik-streaming.html'),(235,3,41,0,75,'online-dating'),(236,3,43,0,75,'online-dating'),(237,3,57,0,75,'online-dating.html'),(238,3,41,0,76,'online-videothek'),(239,3,43,0,76,'online-videothek'),(240,3,57,0,76,'online-videothek.html'),(241,3,41,0,77,'pay-tv'),(242,3,43,0,77,'pay-tv'),(243,3,57,0,77,'pay-tv.html'),(244,3,41,0,78,'server-hosting'),(245,3,43,0,78,'server-hosting'),(246,3,57,0,78,'server-hosting.html'),(247,3,41,0,79,'verlag'),(248,3,43,0,79,'verlag'),(249,3,57,0,79,'verlag.html'),(250,3,41,0,80,'kreditkarte'),(251,3,43,0,80,'kreditkarte'),(252,3,57,0,80,'kreditkarte.html'),(253,3,41,0,81,'leasingvertrag'),(254,3,43,0,81,'leasingvertrag'),(255,3,57,0,81,'leasingvertrag.html'),(256,3,41,0,82,'lotterie'),(257,3,43,0,82,'lotterie'),(258,3,57,0,82,'lotterie.html'),(259,3,41,0,83,'mail-service'),(260,3,43,0,83,'mail-service'),(261,3,57,0,83,'mail-service.html'),(262,3,41,0,84,'mietvertrag'),(263,3,43,0,84,'mietvertrag'),(264,3,57,0,84,'mietvertrag.html'),(265,3,41,0,85,'parteimitgliedschaft'),(266,3,43,0,85,'parteimitgliedschaft'),(267,3,57,0,85,'parteimitgliedschaft.html'),(268,3,41,0,86,'sonnenstudio'),(269,3,43,0,86,'sonnenstudio'),(270,3,57,0,86,'sonnenstudio.html'),(271,3,41,0,87,'sportverein'),(272,3,43,0,87,'sportverein'),(273,3,57,0,87,'sportverein.html'),(274,3,46,0,48,NULL),(275,3,49,0,48,'PRODUCTS'),(276,3,58,0,48,NULL),(277,3,61,0,48,NULL),(278,3,46,0,49,NULL),(279,3,49,0,49,'PRODUCTS'),(280,3,58,0,49,NULL),(281,3,61,0,49,NULL),(282,3,46,0,50,NULL),(283,3,49,0,50,'PRODUCTS'),(284,3,58,0,50,NULL),(285,3,61,0,50,NULL),(286,3,46,0,51,NULL),(287,3,49,0,51,'PRODUCTS'),(288,3,58,0,51,NULL),(289,3,61,0,51,NULL),(290,3,46,0,52,NULL),(291,3,49,0,52,'PRODUCTS'),(292,3,58,0,52,NULL),(293,3,61,0,52,NULL),(294,3,46,0,53,NULL),(295,3,49,0,53,'PRODUCTS'),(296,3,58,0,53,NULL),(297,3,61,0,53,NULL),(298,3,46,0,54,NULL),(299,3,49,0,54,'PRODUCTS'),(300,3,58,0,54,NULL),(301,3,61,0,54,NULL),(302,3,46,0,55,NULL),(303,3,49,0,55,'PRODUCTS'),(304,3,58,0,55,NULL),(305,3,61,0,55,NULL),(306,3,46,0,56,NULL),(307,3,49,0,56,'PRODUCTS'),(308,3,58,0,56,NULL),(309,3,61,0,56,NULL),(310,3,46,0,57,NULL),(311,3,49,0,57,'PRODUCTS'),(312,3,58,0,57,NULL),(313,3,61,0,57,NULL),(314,3,46,0,58,NULL),(315,3,49,0,58,'PRODUCTS'),(316,3,58,0,58,NULL),(317,3,61,0,58,NULL),(318,3,46,0,59,NULL),(319,3,49,0,59,'PRODUCTS'),(320,3,58,0,59,NULL),(321,3,61,0,59,NULL),(322,3,46,0,60,NULL),(323,3,49,0,60,'PRODUCTS'),(324,3,58,0,60,NULL),(325,3,61,0,60,NULL),(326,3,46,0,61,NULL),(327,3,49,0,61,'PRODUCTS'),(328,3,58,0,61,NULL),(329,3,61,0,61,NULL),(330,3,46,0,62,NULL),(331,3,49,0,62,'PRODUCTS'),(332,3,58,0,62,NULL),(333,3,61,0,62,NULL),(334,3,46,0,64,NULL),(335,3,49,0,64,'PRODUCTS'),(336,3,58,0,64,NULL),(337,3,61,0,64,NULL),(338,3,46,0,65,NULL),(339,3,49,0,65,'PRODUCTS'),(340,3,58,0,65,NULL),(341,3,61,0,65,NULL),(342,3,46,0,66,NULL),(343,3,49,0,66,'PRODUCTS'),(344,3,58,0,66,NULL),(345,3,61,0,66,NULL),(346,3,46,0,67,NULL),(347,3,49,0,67,'PRODUCTS'),(348,3,58,0,67,NULL),(349,3,61,0,67,NULL),(350,3,46,0,68,NULL),(351,3,49,0,68,'PRODUCTS'),(352,3,58,0,68,NULL),(353,3,61,0,68,NULL),(354,3,46,0,69,NULL),(355,3,49,0,69,'PRODUCTS'),(356,3,58,0,69,NULL),(357,3,61,0,69,NULL),(358,3,46,0,70,NULL),(359,3,49,0,70,'PRODUCTS'),(360,3,58,0,70,NULL),(361,3,61,0,70,NULL),(362,3,46,0,71,NULL),(363,3,49,0,71,'PRODUCTS'),(364,3,58,0,71,NULL),(365,3,61,0,71,NULL),(366,3,46,0,73,NULL),(367,3,49,0,73,'PRODUCTS'),(368,3,58,0,73,NULL),(369,3,61,0,73,NULL),(370,3,46,0,74,NULL),(371,3,49,0,74,'PRODUCTS'),(372,3,58,0,74,NULL),(373,3,61,0,74,NULL),(374,3,46,0,75,NULL),(375,3,49,0,75,'PRODUCTS'),(376,3,58,0,75,NULL),(377,3,61,0,75,NULL),(378,3,46,0,76,NULL),(379,3,49,0,76,'PRODUCTS'),(380,3,58,0,76,NULL),(381,3,61,0,76,NULL),(382,3,46,0,77,NULL),(383,3,49,0,77,'PRODUCTS'),(384,3,58,0,77,NULL),(385,3,61,0,77,NULL),(386,3,46,0,78,NULL),(387,3,49,0,78,'PRODUCTS'),(388,3,58,0,78,NULL),(389,3,61,0,78,NULL),(390,3,46,0,79,NULL),(391,3,49,0,79,'PRODUCTS'),(392,3,58,0,79,NULL),(393,3,61,0,79,NULL),(394,3,46,0,80,NULL),(395,3,49,0,80,'PRODUCTS'),(396,3,58,0,80,NULL),(397,3,61,0,80,NULL),(398,3,46,0,81,NULL),(399,3,49,0,81,'PRODUCTS'),(400,3,58,0,81,NULL),(401,3,61,0,81,NULL),(402,3,46,0,82,NULL),(403,3,49,0,82,'PRODUCTS'),(404,3,58,0,82,NULL),(405,3,61,0,82,NULL),(406,3,46,0,83,NULL),(407,3,49,0,83,'PRODUCTS'),(408,3,58,0,83,NULL),(409,3,61,0,83,NULL),(410,3,46,0,84,NULL),(411,3,49,0,84,'PRODUCTS'),(412,3,58,0,84,NULL),(413,3,61,0,84,NULL),(414,3,46,0,85,NULL),(415,3,49,0,85,'PRODUCTS'),(416,3,58,0,85,NULL),(417,3,61,0,85,NULL),(418,3,46,0,86,NULL),(419,3,49,0,86,'PRODUCTS'),(420,3,58,0,86,NULL),(421,3,61,0,86,NULL),(422,3,46,0,87,NULL),(423,3,49,0,87,'PRODUCTS'),(424,3,58,0,87,NULL),(425,3,61,0,87,NULL);
/*!40000 ALTER TABLE `catalog_category_entity_varchar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_flat_store_1`
--

DROP TABLE IF EXISTS `catalog_category_flat_store_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_flat_store_1` (
  `entity_id` int(10) unsigned NOT NULL COMMENT 'entity_id',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'parent_id',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'created_at',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'updated_at',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT 'path',
  `position` int(11) NOT NULL COMMENT 'position',
  `level` int(11) NOT NULL DEFAULT '0' COMMENT 'level',
  `children_count` int(11) NOT NULL COMMENT 'children_count',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store Id',
  `all_children` text COMMENT 'All Children',
  `available_sort_by` text COMMENT 'Available Product Listing Sort By',
  `children` text COMMENT 'Children',
  `custom_apply_to_products` int(11) DEFAULT NULL COMMENT 'Apply To Products',
  `custom_design` varchar(255) DEFAULT NULL COMMENT 'Custom Design',
  `custom_design_from` datetime DEFAULT NULL COMMENT 'Active From',
  `custom_design_to` datetime DEFAULT NULL COMMENT 'Active To',
  `custom_layout_update` text COMMENT 'Custom Layout Update',
  `custom_use_parent_settings` int(11) DEFAULT NULL COMMENT 'Use Parent Category Settings',
  `default_sort_by` varchar(255) DEFAULT NULL COMMENT 'Default Product Listing Sort By',
  `description` text COMMENT 'Description',
  `display_mode` varchar(255) DEFAULT NULL COMMENT 'Display Mode',
  `filter_price_range` decimal(12,4) DEFAULT NULL COMMENT 'Layered Navigation Price Step',
  `image` varchar(255) DEFAULT NULL COMMENT 'Image',
  `include_in_menu` int(11) DEFAULT NULL COMMENT 'Include in Navigation Menu',
  `is_active` int(11) DEFAULT NULL COMMENT 'Is Active',
  `is_anchor` int(11) DEFAULT NULL COMMENT 'Is Anchor',
  `landing_page` int(11) DEFAULT NULL COMMENT 'CMS Block',
  `meta_description` text COMMENT 'Meta Description',
  `meta_keywords` text COMMENT 'Meta Keywords',
  `meta_title` varchar(255) DEFAULT NULL COMMENT 'Page Title',
  `name` varchar(255) DEFAULT NULL COMMENT 'Name',
  `page_layout` varchar(255) DEFAULT NULL COMMENT 'Page Layout',
  `path_in_store` text COMMENT 'Path In Store',
  `thumbnail` varchar(255) DEFAULT NULL COMMENT 'Thumbnail Image',
  `url_key` varchar(255) DEFAULT NULL COMMENT 'URL Key',
  `url_path` varchar(255) DEFAULT NULL COMMENT 'Url Path',
  PRIMARY KEY (`entity_id`),
  KEY `IDX_CATALOG_CATEGORY_FLAT_STORE_1_STORE_ID` (`store_id`),
  KEY `IDX_CATALOG_CATEGORY_FLAT_STORE_1_PATH` (`path`),
  KEY `IDX_CATALOG_CATEGORY_FLAT_STORE_1_LEVEL` (`level`),
  CONSTRAINT `FK_CATALOG_CATEGORY_FLAT_STORE_1_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_FLAT_STORE_1_ENTT_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`entity_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog Category Flat (Store 1)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_flat_store_1`
--

LOCK TABLES `catalog_category_flat_store_1` WRITE;
/*!40000 ALTER TABLE `catalog_category_flat_store_1` DISABLE KEYS */;
INSERT INTO `catalog_category_flat_store_1` VALUES (1,0,'2014-05-15 23:02:15','2014-05-15 23:02:16','1',0,0,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'Root Catalog',NULL,NULL,NULL,'root-catalog',NULL),(2,1,'2014-05-15 23:02:18','2014-05-15 23:02:18','1/2',1,1,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PRODUCTS',NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,'Default Category',NULL,NULL,NULL,'default-category',NULL);
/*!40000 ALTER TABLE `catalog_category_flat_store_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_product`
--

DROP TABLE IF EXISTS `catalog_category_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_product` (
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Category ID',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Product ID',
  `position` int(11) NOT NULL DEFAULT '0' COMMENT 'Position',
  PRIMARY KEY (`category_id`,`product_id`),
  KEY `IDX_CATALOG_CATEGORY_PRODUCT_PRODUCT_ID` (`product_id`),
  CONSTRAINT `FK_CAT_CTGR_PRD_CTGR_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`category_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_PRD_PRD_ID_CAT_PRD_ENTT_ENTT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog Product To Category Linkage Table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_product`
--

LOCK TABLES `catalog_category_product` WRITE;
/*!40000 ALTER TABLE `catalog_category_product` DISABLE KEYS */;
INSERT INTO `catalog_category_product` VALUES (2,7033,0),(2,7034,0),(2,7035,0),(2,7036,0),(2,7037,0),(2,7038,0),(2,7039,0),(2,7040,0),(2,7041,0),(2,7042,0),(2,7043,0),(2,7044,0),(2,7045,0),(49,7038,0),(50,7033,0),(51,7034,0),(51,7040,0),(52,7039,0),(53,7035,0),(56,7036,0),(60,7037,0),(62,7041,0),(62,7042,0),(62,7043,0),(62,7044,0),(62,7045,0);
/*!40000 ALTER TABLE `catalog_category_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_category_product_index`
--

DROP TABLE IF EXISTS `catalog_category_product_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_category_product_index` (
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Category ID',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Product ID',
  `position` int(11) DEFAULT NULL COMMENT 'Position',
  `is_parent` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Is Parent',
  `store_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `visibility` smallint(5) unsigned NOT NULL COMMENT 'Visibility',
  PRIMARY KEY (`category_id`,`product_id`,`store_id`),
  KEY `IDX_CAT_CTGR_PRD_IDX_PRD_ID_STORE_ID_CTGR_ID_VISIBILITY` (`product_id`,`store_id`,`category_id`,`visibility`),
  KEY `9F0DE3351D175F137D28704CB260F849` (`store_id`,`category_id`,`visibility`,`is_parent`,`position`),
  CONSTRAINT `FK_CAT_CTGR_PRD_IDX_CTGR_ID_CAT_CTGR_ENTT_ENTT_ID` FOREIGN KEY (`category_id`) REFERENCES `catalog_category_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_PRD_IDX_PRD_ID_CAT_PRD_ENTT_ENTT_ID` FOREIGN KEY (`product_id`) REFERENCES `catalog_product_entity` (`entity_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_CAT_CTGR_PRD_IDX_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog Category Product Index';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_category_product_index`
--

LOCK TABLES `catalog_category_product_index` WRITE;
/*!40000 ALTER TABLE `catalog_category_product_index` DISABLE KEYS */;
INSERT INTO `catalog_category_product_index` VALUES (2,1,0,1,1,4),(2,7033,0,1,1,4),(2,7034,0,1,1,4),(2,7035,0,1,1,4),(2,7036,0,1,1,4),(2,7037,0,1,1,4),(2,7038,0,1,1,4),(2,7039,0,1,1,4),(2,7040,0,1,1,4),(2,7041,0,1,1,4),(2,7042,0,1,1,4),(2,7043,0,1,1,4),(2,7044,0,1,1,4),(2,7045,0,1,1,4),(49,7038,0,1,1,4),(50,7033,0,1,1,4),(51,7034,0,1,1,4),(51,7040,0,1,1,4),(52,7039,0,1,1,4),(53,7035,0,1,1,4),(56,7036,0,1,1,4),(60,7037,0,1,1,4),(62,7041,0,1,1,4),(62,7042,0,1,1,4),(62,7043,0,1,1,4),(62,7044,0,1,1,4),(62,7045,0,1,1,4);
/*!40000 ALTER TABLE `catalog_category_product_index` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-16 16:29:29
